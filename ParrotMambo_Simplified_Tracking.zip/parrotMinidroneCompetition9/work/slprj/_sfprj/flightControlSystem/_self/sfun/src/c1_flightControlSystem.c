/* Include files */

#include "flightControlSystem_sfun.h"
#include "c1_flightControlSystem.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtMCInfo c1_emlrtMCI = { 13, /* lineNo */
  9,                                   /* colNo */
  "sqrt",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\elfun\\sqrt.m"/* pName */
};

static emlrtMCInfo c1_b_emlrtMCI = { 13,/* lineNo */
  13,                                  /* colNo */
  "toLogicalCheck",                    /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\eml\\+coder\\+internal\\toLogicalCheck.m"/* pName */
};

static emlrtMCInfo c1_c_emlrtMCI = { 87,/* lineNo */
  33,                                  /* colNo */
  "eml_int_forloop_overflow_check",    /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pName */
};

static emlrtMCInfo c1_d_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatefinite",                    /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatefinite.m"/* pName */
};

static emlrtMCInfo c1_e_emlrtMCI = { 13,/* lineNo */
  37,                                  /* colNo */
  "validateinteger",                   /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validateinteger.m"/* pName */
};

static emlrtMCInfo c1_f_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatenonnan",                    /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatenonnan.m"/* pName */
};

static emlrtMCInfo c1_g_emlrtMCI = { 454,/* lineNo */
  5,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtMCInfo c1_h_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validatepositive",                  /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validatepositive.m"/* pName */
};

static emlrtMCInfo c1_i_emlrtMCI = { 14,/* lineNo */
  37,                                  /* colNo */
  "validateodd",                       /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\eml\\+coder\\+internal\\+valattr\\validateodd.m"/* pName */
};

static emlrtMCInfo c1_j_emlrtMCI = { 474,/* lineNo */
  1,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtMCInfo c1_k_emlrtMCI = { 40,/* lineNo */
  15,                                  /* colNo */
  "ind2sub",                           /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\elmat\\ind2sub.m"/* pName */
};

static emlrtMCInfo c1_l_emlrtMCI = { 18,/* lineNo */
  15,                                  /* colNo */
  "mean",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\datafun\\mean.m"/* pName */
};

static emlrtRSInfo c1_emlrtRSI = { 2,  /* lineNo */
  "Image Processing System/MATLAB Function",/* fcnName */
  "#flightControlSystem:2766"          /* pathName */
};

static emlrtRSInfo c1_b_emlrtRSI = { 3,/* lineNo */
  "Image Processing System/MATLAB Function",/* fcnName */
  "#flightControlSystem:2766"          /* pathName */
};

static emlrtRSInfo c1_c_emlrtRSI = { 4,/* lineNo */
  "Image Processing System/MATLAB Function",/* fcnName */
  "#flightControlSystem:2766"          /* pathName */
};

static emlrtRSInfo c1_d_emlrtRSI = { 5,/* lineNo */
  "Image Processing System/MATLAB Function",/* fcnName */
  "#flightControlSystem:2766"          /* pathName */
};

static emlrtRSInfo c1_e_emlrtRSI = { 116,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_f_emlrtRSI = { 132,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_g_emlrtRSI = { 138,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_h_emlrtRSI = { 708,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_i_emlrtRSI = { 709,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_j_emlrtRSI = { 714,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_k_emlrtRSI = { 715,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_l_emlrtRSI = { 106,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_m_emlrtRSI = { 110,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_n_emlrtRSI = { 854,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_o_emlrtRSI = { 928,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_p_emlrtRSI = { 1002,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_q_emlrtRSI = { 1030,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_r_emlrtRSI = { 1042,/* lineNo */
  "imfilter",                          /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imfilter.m"/* pathName */
};

static emlrtRSInfo c1_s_emlrtRSI = { 724,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_t_emlrtRSI = { 133,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_u_emlrtRSI = { 170,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_v_emlrtRSI = { 456,/* lineNo */
  "imhist",                            /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imhist.m"/* pathName */
};

static emlrtRSInfo c1_w_emlrtRSI = { 14,/* lineNo */
  "warning",                           /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\shared\\coder\\coder\\lib\\+coder\\+internal\\warning.m"/* pathName */
};

static emlrtRSInfo c1_x_emlrtRSI = { 762,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_y_emlrtRSI = { 768,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_ab_emlrtRSI = { 872,/* lineNo */
  "edge",                              /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pathName */
};

static emlrtRSInfo c1_bb_emlrtRSI = { 40,/* lineNo */
  "imreconstruct",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imreconstruct.m"/* pathName */
};

static emlrtRSInfo c1_cb_emlrtRSI = { 76,/* lineNo */
  "imreconstruct",                     /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\imreconstruct.m"/* pathName */
};

static emlrtRSInfo c1_db_emlrtRSI = { 27,/* lineNo */
  "getBinaryConnectivityMatrix",       /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\+images\\+internal\\getBinaryConnectivityMatrix.m"/* pathName */
};

static emlrtRSInfo c1_eb_emlrtRSI = { 60,/* lineNo */
  "hough",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\hough.m"/* pathName */
};

static emlrtRSInfo c1_fb_emlrtRSI = { 290,/* lineNo */
  "hough",                             /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\hough.m"/* pathName */
};

static emlrtRSInfo c1_gb_emlrtRSI = { 111,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_hb_emlrtRSI = { 61,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_ib_emlrtRSI = { 274,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_jb_emlrtRSI = { 317,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_kb_emlrtRSI = { 321,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_lb_emlrtRSI = { 324,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_mb_emlrtRSI = { 93,/* lineNo */
  "validateattributes",                /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"/* pathName */
};

static emlrtRSInfo c1_nb_emlrtRSI = { 427,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_ob_emlrtRSI = { 439,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_pb_emlrtRSI = { 474,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_qb_emlrtRSI = { 463,/* lineNo */
  "houghpeaks",                        /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pathName */
};

static emlrtRSInfo c1_rb_emlrtRSI = { 19,/* lineNo */
  "ind2sub",                           /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\elmat\\ind2sub.m"/* pathName */
};

static emlrtRSInfo c1_sb_emlrtRSI = { 20,/* lineNo */
  "eml_int_forloop_overflow_check",    /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pathName */
};

static emlrtRSInfo c1_tb_emlrtRSI = { 183,/* lineNo */
  "sumMatrixIncludeNaN",               /* fcnName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumMatrixIncludeNaN.m"/* pathName */
};

static emlrtRTEInfo c1_emlrtRTEI = { 5,/* lineNo */
  17,                                  /* colNo */
  "Image Processing System/MATLAB Function",/* fName */
  "#flightControlSystem:2766"          /* pName */
};

static emlrtRTEInfo c1_b_emlrtRTEI = { 99,/* lineNo */
  40,                                  /* colNo */
  "blockedSummation",                  /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\datafun\\private\\blockedSummation.m"/* pName */
};

static emlrtRTEInfo c1_c_emlrtRTEI = { 739,/* lineNo */
  9,                                   /* colNo */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c1_d_emlrtRTEI = { 740,/* lineNo */
  37,                                  /* colNo */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c1_e_emlrtRTEI = { 76,/* lineNo */
  9,                                   /* colNo */
  "eml_mtimes_helper",                 /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"/* pName */
};

static emlrtRTEInfo c1_f_emlrtRTEI = { 740,/* lineNo */
  9,                                   /* colNo */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m"/* pName */
};

static emlrtRTEInfo c1_g_emlrtRTEI = { 191,/* lineNo */
  5,                                   /* colNo */
  "houghpeaks",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m"/* pName */
};

static emlrtBCInfo c1_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  5,                                   /* lineNo */
  23,                                  /* colNo */
  "P",                                 /* aName */
  "Image Processing System/MATLAB Function",/* fName */
  "#flightControlSystem:2766",         /* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_b_emlrtBCI = { 1,/* iFirst */
  180,                                 /* iLast */
  5,                                   /* lineNo */
  19,                                  /* colNo */
  "T",                                 /* aName */
  "Image Processing System/MATLAB Function",/* fName */
  "#flightControlSystem:2766",         /* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c1_emlrtDCI = { 5,  /* lineNo */
  19,                                  /* colNo */
  "Image Processing System/MATLAB Function",/* fName */
  "#flightControlSystem:2766",         /* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c1_c_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  767,                                 /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_d_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  762,                                 /* lineNo */
  70,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_e_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  142,                                 /* lineNo */
  28,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_f_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  141,                                 /* lineNo */
  27,                                  /* colNo */
  "",                                  /* aName */
  "edge",                              /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\edge.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_g_emlrtBCI = { 1,/* iFirst */
  118,                                 /* iLast */
  100,                                 /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "padarray",                          /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\padarray.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_h_emlrtBCI = { 1,/* iFirst */
  158,                                 /* iLast */
  100,                                 /* lineNo */
  42,                                  /* colNo */
  "",                                  /* aName */
  "padarray",                          /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\padarray.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c1_i_emlrtBCI = { 1,/* iFirst */
  393,                                 /* iLast */
  301,                                 /* lineNo */
  30,                                  /* colNo */
  "",                                  /* aName */
  "hough",                             /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\hough.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c1_j_emlrtBCI = { 1,/* iFirst */
  118,                                 /* iLast */
  348,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "hough",                             /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\hough.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c1_k_emlrtBCI = { 1,/* iFirst */
  2,                                   /* iLast */
  122,                                 /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "houghpeaks",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m",/* pName */
  3                                    /* checkKind */
};

static emlrtBCInfo c1_l_emlrtBCI = { 1,/* iFirst */
  393,                                 /* iLast */
  119,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "houghpeaks",                        /* fName */
  "C:\\Program Files\\MATLAB\\R2022b\\toolbox\\images\\images\\eml\\houghpeaks.m",/* pName */
  0                                    /* checkKind */
};

static int32_T c1_iv[316] = { 1, 1, 1, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
  31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
  51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
  71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
  91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107,
  108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 118, 118, 118, 118, 118,
  118, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
  21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
  41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
  61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
  81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
  100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115,
  116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131,
  132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147,
  148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158 };

static real_T c1_dv[13] = { 3.4813359214923059E-5, 0.00054457256285105158,
  0.0051667606200595222, 0.029732654490475543, 0.10377716120747747,
  0.21969625200024598, 0.28209557151935094, 0.21969625200024598,
  0.10377716120747747, 0.029732654490475543, 0.0051667606200595222,
  0.00054457256285105158, 3.4813359214923059E-5 };

static int32_T c1_iv1[340] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
  16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,
  36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
  56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75,
  76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
  96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
  112, 113, 114, 115, 116, 117, 118, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9,
  10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
  30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
  50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
  70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89,
  90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107,
  108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123,
  124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139,
  140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155,
  156, 157, 158, 158, 158, 158, 158, 158, 158 };

static real_T c1_dv1[13] = { 0.0020299751839417137, 0.0102182810143517,
  0.058116735860084034, 0.19634433732941292, 0.37823877042972087,
  0.35505190018248872, 0.0, -0.35505190018248872, -0.37823877042972087,
  -0.19634433732941292, -0.058116735860084034, -0.0102182810143517,
  -0.0020299751839417137 };

static real_T c1_dv2[12] = { 0.0020299751839417137, 0.0102182810143517,
  0.058116735860084034, 0.19634433732941292, 0.37823877042972087,
  0.35505190018248872, -0.35505190018248872, -0.37823877042972087,
  -0.19634433732941292, -0.058116735860084034, -0.0102182810143517,
  -0.0020299751839417137 };

static boolean_T c1_bv[13] = { true, true, true, true, true, true, false, true,
  true, true, true, true, true };

static char_T c1_cv[32] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o', 'u',
  'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
  'F', 'i', 'n', 'i', 't', 'e' };

static char_T c1_cv1[46] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
  'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't', 'r',
  'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'F', 'i',
  'n', 'i', 't', 'e' };

static char_T c1_cv2[33] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o', 'u',
  'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd',
  'I', 'n', 't', 'e', 'g', 'e', 'r' };

static char_T c1_cv3[47] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
  'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't', 't', 'r',
  'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e', 'd', 'I', 'n',
  't', 'e', 'g', 'e', 'r' };

/* Function Declarations */
static void initialize_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void initialize_params_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_start_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_terminate_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void enable_c1_flightControlSystem(SFc1_flightControlSystemInstanceStruct
  *chartInstance);
static void disable_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void sf_gateway_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void ext_mode_exec_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_update_jit_animation_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_do_animation_call_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void set_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance, const mxArray *c1_st);
static void initSimStructsc1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_edge(SFc1_flightControlSystemInstanceStruct *chartInstance, const
                    emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], boolean_T
                    c1_varargout_1[18644]);
static void c1_imfilter(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], real_T c1_b[18644]);
static void c1_b_imfilter(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], real_T c1_b[18644]);
static void c1_c_imfilter(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], real_T c1_b[18644]);
static void c1_warning(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp);
static void c1_hough(SFc1_flightControlSystemInstanceStruct *chartInstance,
                     const emlrtStack *c1_sp, boolean_T c1_b_varargin_1[18644],
                     real_T c1_h[70740]);
static void c1_houghpeaks(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[70740], real_T c1_peaks_data[],
  int32_T c1_peaks_size[2]);
static void c1_validateattributes(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c1_sp, real_T c1_c_a[2]);
static void c1_diff(SFc1_flightControlSystemInstanceStruct *chartInstance,
                    real_T c1_x[180], real_T c1_y[179]);
static void c1_b_diff(SFc1_flightControlSystemInstanceStruct *chartInstance,
                      real_T c1_x[179], real_T c1_y[178]);
static real_T c1_sumColumnB(SFc1_flightControlSystemInstanceStruct
  *chartInstance, real_T c1_x[178]);
static real_T c1_b_sumColumnB(SFc1_flightControlSystemInstanceStruct
  *chartInstance, real_T c1_x_data[], int32_T c1_vlen);
static real_T c1_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_b_DegAngle, const char_T *c1_identifier);
static real_T c1_b_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static uint8_T c1_c_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_b_is_active_c1_flightControlSystem, const
  char_T *c1_identifier);
static uint8_T c1_d_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static void c1_slStringInitializeDynamicBuffers
  (SFc1_flightControlSystemInstanceStruct *chartInstance);
static void c1_chart_data_browse_helper(SFc1_flightControlSystemInstanceStruct
  *chartInstance, int32_T c1_ssIdNumber, const mxArray **c1_mxData, uint8_T
  *c1_isValueTooBig);
static const mxArray *c1_feval(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c1_sp, const mxArray *c1_input0, const
  mxArray *c1_input1);
static void c1_b_feval(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, const mxArray *c1_input0, const mxArray *c1_input1);
static void init_dsm_address_info(SFc1_flightControlSystemInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc1_flightControlSystemInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  emlrtStack c1_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  c1_st.tls = chartInstance->c1_fEmlrtCtx;
  emlrtLicenseCheckR2022a(&c1_st, "EMLRT:runTime:MexFunctionNeedsLicense",
    "image_toolbox", 2);
  sim_mode_is_external(chartInstance->S);
  chartInstance->c1_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c1_is_active_c1_flightControlSystem = 0U;
}

static void initialize_params_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_start_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_terminate_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  static const uint32_T c1_decisionTxtEndIdx = 0U;
  static const uint32_T c1_decisionTxtStartIdx = 0U;
  setDebuggerFlag(chartInstance->S, true);
  setDataBrowseFcn(chartInstance->S, (void *)&c1_chart_data_browse_helper);
  chartInstance->c1_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c1_RuntimeVar,
    &chartInstance->c1_IsDebuggerActive,
    &chartInstance->c1_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c1_mlFcnLineNumber, &chartInstance->c1_IsHeatMapPresent, 0);
  sim_mode_is_external(chartInstance->S);
  covrtCreateStateflowInstanceData(chartInstance->c1_covrtInstance, 1U, 0U, 1U,
    27U);
  covrtChartInitFcn(chartInstance->c1_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c1_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c1_decisionTxtStartIdx, &c1_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c1_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c1_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c1_covrtInstance, 4U, 0U, 0U,
                     "eML_blk_kernel", 0, -1, 209);
}

static void mdl_cleanup_runtime_resources_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c1_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c1_covrtInstance);
}

static void enable_c1_flightControlSystem(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  static char_T c1_b_cv[36] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'a', 'u', 't', 'o', 'D', 'i', 'm', 'I', 'n', 'c', 'o',
    'm', 'p', 'a', 't', 'i', 'b', 'i', 'l', 'i', 't', 'y' };

  emlrtStack c1_b_st;
  emlrtStack c1_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  const mxArray *c1_b_y = NULL;
  const mxArray *c1_y = NULL;
  real_T c1_P_data[4];
  real_T c1_b_x_data[2];
  real_T c1_x_data[2];
  real_T c1_b_DegAngle;
  real_T c1_c_y;
  real_T c1_d;
  int32_T c1_P_size[2];
  int32_T c1_x_size[2];
  int32_T c1_b_loop_ub;
  int32_T c1_b_vlen;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_c_vlen;
  int32_T c1_d_vlen;
  int32_T c1_i;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_loop_ub;
  int32_T c1_vlen;
  boolean_T c1_edgedBW[18644];
  boolean_T c1_b;
  boolean_T c1_b1;
  boolean_T c1_b2;
  c1_st.tls = chartInstance->c1_fEmlrtCtx;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  chartInstance->c1_JITTransitionAnimation[0] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  for (c1_i = 0; c1_i < 18644; c1_i++) {
    covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 0U,
                      (*chartInstance->c1_BWimage)[c1_i]);
  }

  chartInstance->c1_sfEvent = CALL_EVENT;
  covrtEmlFcnEval(chartInstance->c1_covrtInstance, 4U, 0, 0);
  c1_b_st.site = &c1_emlrtRSI;
  for (c1_c_i1 = 0; c1_c_i1 < 18644; c1_c_i1++) {
    chartInstance->c1_b_dv[c1_c_i1] = (*chartInstance->c1_BWimage)[c1_c_i1];
  }

  c1_edge(chartInstance, &c1_b_st, chartInstance->c1_b_dv, c1_edgedBW);
  c1_b_st.site = &c1_b_emlrtRSI;
  c1_hough(chartInstance, &c1_b_st, c1_edgedBW, chartInstance->c1_H);
  c1_b_st.site = &c1_c_emlrtRSI;
  c1_houghpeaks(chartInstance, &c1_b_st, chartInstance->c1_H, c1_P_data,
                c1_P_size);
  c1_b_st.site = &c1_d_emlrtRSI;
  c1_c_i2 = 2;
  if ((c1_c_i2 < 1) || (c1_c_i2 > c1_P_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c1_c_i2, 1, c1_P_size[1], &c1_emlrtBCI,
      &c1_b_st);
  }

  c1_i3 = c1_c_i2 - 1;
  c1_x_size[1] = c1_P_size[0];
  c1_loop_ub = c1_P_size[0] - 1;
  for (c1_i4 = 0; c1_i4 <= c1_loop_ub; c1_i4++) {
    c1_d = c1_P_data[c1_i4 + c1_P_size[0] * c1_i3];
    if (c1_d != (real_T)(int32_T)muDoubleScalarFloor(c1_d)) {
      emlrtIntegerCheckR2012b(c1_d, &c1_emlrtDCI, &c1_b_st);
    }

    c1_i5 = (int32_T)c1_d;
    if ((c1_i5 < 1) || (c1_i5 > 180)) {
      emlrtDynamicBoundsCheckR2012b(c1_i5, 1, 180, &c1_b_emlrtBCI, &c1_b_st);
    }

    c1_x_data[c1_i4] = -90.0 + (real_T)(c1_i5 - 1);
  }

  c1_b = (c1_x_size[1] == 1);
  if (c1_b || ((real_T)c1_x_size[1] != 1.0)) {
    c1_b1 = true;
  } else {
    c1_b1 = false;
  }

  if (!c1_b1) {
    c1_y = NULL;
    sf_mex_assign(&c1_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    c1_b_y = NULL;
    sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call(&c1_b_st, &c1_l_emlrtMCI, "error", 0U, 2U, 14, c1_y, 14,
                sf_mex_call(&c1_b_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_b_st, NULL, "message", 1U, 1U, 14, c1_b_y)));
  }

  c1_vlen = c1_x_size[1];
  c1_b_vlen = c1_vlen;
  c1_b2 = (c1_x_size[1] == 0);
  if (c1_b2 || (c1_b_vlen == 0)) {
    c1_c_y = 0.0;
  } else {
    c1_b_loop_ub = c1_x_size[1] - 1;
    for (c1_i6 = 0; c1_i6 <= c1_b_loop_ub; c1_i6++) {
      c1_b_x_data[c1_i6] = c1_x_data[c1_i6];
    }

    c1_c_vlen = c1_b_vlen;
    c1_d_vlen = c1_c_vlen;
    c1_c_y = c1_b_sumColumnB(chartInstance, c1_b_x_data, c1_d_vlen);
  }

  c1_b_DegAngle = c1_c_y / (real_T)c1_x_size[1];
  *chartInstance->c1_DegAngle = c1_b_DegAngle;
  c1_do_animation_call_c1_flightControlSystem(chartInstance);
  covrtSigUpdateFcn(chartInstance->c1_covrtInstance, 1U,
                    *chartInstance->c1_DegAngle);
}

static void ext_mode_exec_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_update_jit_animation_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_do_animation_call_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static const mxArray *get_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_st;
  const mxArray *c1_y = NULL;
  c1_st = NULL;
  c1_st = NULL;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_createcellmatrix(2, 1), false);
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", chartInstance->c1_DegAngle, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 0, c1_b_y);
  c1_c_y = NULL;
  sf_mex_assign(&c1_c_y, sf_mex_create("y",
    &chartInstance->c1_is_active_c1_flightControlSystem, 3, 0U, 0U, 0U, 0),
                false);
  sf_mex_setcell(c1_y, 1, c1_c_y);
  sf_mex_assign(&c1_st, c1_y, false);
  return c1_st;
}

static void set_sim_state_c1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance, const mxArray *c1_st)
{
  const mxArray *c1_u;
  chartInstance->c1_doneDoubleBufferReInit = true;
  c1_u = sf_mex_dup(c1_st);
  *chartInstance->c1_DegAngle = c1_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c1_u, 0)), "DegAngle");
  chartInstance->c1_is_active_c1_flightControlSystem = c1_c_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 1)),
     "is_active_c1_flightControlSystem");
  sf_mex_destroy(&c1_u);
  sf_mex_destroy(&c1_st);
}

static void initSimStructsc1_flightControlSystem
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info(void)
{
  const mxArray *c1_nameCaptureInfo = NULL;
  c1_nameCaptureInfo = NULL;
  sf_mex_assign(&c1_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c1_nameCaptureInfo;
}

static void c1_edge(SFc1_flightControlSystemInstanceStruct *chartInstance, const
                    emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], boolean_T
                    c1_varargout_1[18644])
{
  emlrtStack c1_b_st;
  emlrtStack c1_c_st;
  emlrtStack c1_d_st;
  emlrtStack c1_st;
  real_T c1_counts[64];
  real_T c1_connDimsT[2];
  real_T c1_outSizeT[2];
  real_T c1_padSizeT[2];
  real_T c1_startT[2];
  real_T c1_b_data[1];
  real_T c1_highThresh_data[1];
  real_T c1_lowThresh_data[1];
  real_T c1_b;
  real_T c1_b_b;
  real_T c1_b_idx;
  real_T c1_b_j;
  real_T c1_b_lowThresh;
  real_T c1_b_r;
  real_T c1_b_x;
  real_T c1_b_x1;
  real_T c1_b_x2;
  real_T c1_b_y;
  real_T c1_c_a;
  real_T c1_c_b;
  real_T c1_c_i;
  real_T c1_c_varargin_1;
  real_T c1_c_x;
  real_T c1_c_y;
  real_T c1_d_a;
  real_T c1_d_b;
  real_T c1_d_idx;
  real_T c1_d_x;
  real_T c1_d_y;
  real_T c1_e_a;
  real_T c1_e_x;
  real_T c1_e_y;
  real_T c1_f_a;
  real_T c1_f_i;
  real_T c1_f_x;
  real_T c1_f_y;
  real_T c1_g_a;
  real_T c1_g_b;
  real_T c1_g_x;
  real_T c1_g_y;
  real_T c1_h_a;
  real_T c1_h_x;
  real_T c1_h_y;
  real_T c1_highThresh;
  real_T c1_highThreshTemp;
  real_T c1_i_a;
  real_T c1_i_x;
  real_T c1_i_y;
  real_T c1_j_x;
  real_T c1_k_x;
  real_T c1_lowThresh;
  real_T c1_magmax;
  real_T c1_out;
  real_T c1_r;
  real_T c1_sum;
  real_T c1_varargin_2;
  real_T c1_x;
  real_T c1_x1;
  real_T c1_x2;
  real_T c1_y;
  int32_T c1_highThresh_size[1];
  int32_T c1_lowThresh_size[1];
  int32_T c1_b_c;
  int32_T c1_b_i;
  int32_T c1_c;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_d_i;
  int32_T c1_e_i;
  int32_T c1_i;
  int32_T c1_i10;
  int32_T c1_i11;
  int32_T c1_i12;
  int32_T c1_i13;
  int32_T c1_i14;
  int32_T c1_i15;
  int32_T c1_i16;
  int32_T c1_i17;
  int32_T c1_i18;
  int32_T c1_i19;
  int32_T c1_i20;
  int32_T c1_i21;
  int32_T c1_i22;
  int32_T c1_i23;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i7;
  int32_T c1_i8;
  int32_T c1_i9;
  int32_T c1_idx;
  int32_T c1_j;
  int32_T c1_loop_ub;
  int8_T c1_c_idx;
  boolean_T c1_E[18644];
  boolean_T c1_conn[13];
  boolean_T c1_b_modeFlag;
  boolean_T c1_c_modeFlag;
  boolean_T c1_e_b;
  boolean_T c1_f_b;
  boolean_T c1_modeFlag;
  boolean_T c1_nanFlag;
  boolean_T c1_tooBig;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_st.site = &c1_e_emlrtRSI;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_c_st.prev = &c1_b_st;
  c1_c_st.tls = c1_b_st.tls;
  c1_d_st.prev = &c1_c_st;
  c1_d_st.tls = c1_c_st.tls;
  c1_b_st.site = &c1_h_emlrtRSI;
  c1_c_st.site = &c1_l_emlrtRSI;
  c1_d_st.site = &c1_n_emlrtRSI;
  for (c1_j = 0; c1_j < 158; c1_j++) {
    c1_b_j = (real_T)c1_j + 1.0;
    for (c1_i = 0; c1_i < 130; c1_i++) {
      c1_c_i = (real_T)c1_i + 1.0;
      if ((c1_iv[(int32_T)c1_c_i - 1] < 1) || (c1_iv[(int32_T)c1_c_i - 1] > 118))
      {
        emlrtDynamicBoundsCheckR2012b(c1_iv[(int32_T)c1_c_i - 1], 1, 118,
          &c1_g_emlrtBCI, &c1_d_st);
      }

      c1_d_i = c1_iv[(int32_T)c1_b_j + 157];
      if ((c1_d_i < 1) || (c1_d_i > 158)) {
        emlrtDynamicBoundsCheckR2012b(c1_d_i, 1, 158, &c1_h_emlrtBCI, &c1_d_st);
      }

      chartInstance->c1_a[((int32_T)c1_c_i + 130 * ((int32_T)c1_b_j - 1)) - 1] =
        c1_b_varargin_1[(c1_iv[(int32_T)c1_c_i - 1] + 118 * (c1_d_i - 1)) - 1];
    }
  }

  c1_c_st.site = &c1_m_emlrtRSI;
  c1_d_st.site = &c1_o_emlrtRSI;
  c1_tooBig = true;
  for (c1_b_i = 0; c1_b_i < 2; c1_b_i++) {
    c1_tooBig = false;
  }

  if (!c1_tooBig) {
    c1_modeFlag = true;
  } else {
    c1_modeFlag = false;
  }

  if (c1_modeFlag) {
    c1_b_modeFlag = true;
  } else {
    c1_b_modeFlag = false;
  }

  c1_c_modeFlag = c1_b_modeFlag;
  if (c1_c_modeFlag) {
    for (c1_c_i2 = 0; c1_c_i2 < 2; c1_c_i2++) {
      c1_padSizeT[c1_c_i2] = 130.0 + 28.0 * (real_T)c1_c_i2;
    }

    for (c1_i4 = 0; c1_i4 < 2; c1_i4++) {
      c1_outSizeT[c1_i4] = 118.0 + 40.0 * (real_T)c1_i4;
    }

    for (c1_i6 = 0; c1_i6 < 2; c1_i6++) {
      c1_connDimsT[c1_i6] = 13.0 + -12.0 * (real_T)c1_i6;
    }

    ippfilter_real64(&chartInstance->c1_a[0], &chartInstance->c1_i1[0],
                     &c1_outSizeT[0], 2.0, &c1_padSizeT[0], &c1_dv[0],
                     &c1_connDimsT[0], true);
  } else {
    for (c1_c_i1 = 0; c1_c_i1 < 13; c1_c_i1++) {
      c1_conn[c1_c_i1] = true;
    }

    for (c1_i3 = 0; c1_i3 < 2; c1_i3++) {
      c1_padSizeT[c1_i3] = 130.0 + 28.0 * (real_T)c1_i3;
    }

    for (c1_i5 = 0; c1_i5 < 2; c1_i5++) {
      c1_outSizeT[c1_i5] = 118.0 + 40.0 * (real_T)c1_i5;
    }

    for (c1_i7 = 0; c1_i7 < 2; c1_i7++) {
      c1_connDimsT[c1_i7] = 13.0 + -12.0 * (real_T)c1_i7;
    }

    for (c1_i8 = 0; c1_i8 < 2; c1_i8++) {
      c1_startT[c1_i8] = 6.0 + -6.0 * (real_T)c1_i8;
    }

    imfilter_real64(&chartInstance->c1_a[0], &chartInstance->c1_i1[0], 2.0,
                    &c1_outSizeT[0], 2.0, &c1_padSizeT[0], &c1_dv[0], 13.0,
                    &c1_conn[0], 2.0, &c1_connDimsT[0], &c1_startT[0], 2.0, true,
                    true);
  }

  for (c1_i9 = 0; c1_i9 < 18644; c1_i9++) {
    chartInstance->c1_b_i1[c1_i9] = chartInstance->c1_i1[c1_i9];
  }

  c1_b_st.site = &c1_i_emlrtRSI;
  c1_imfilter(chartInstance, &c1_b_st, chartInstance->c1_b_i1,
              chartInstance->c1_i1);
  c1_b_st.site = &c1_j_emlrtRSI;
  c1_b_imfilter(chartInstance, &c1_b_st, c1_b_varargin_1, chartInstance->c1_i2);
  for (c1_i10 = 0; c1_i10 < 18644; c1_i10++) {
    chartInstance->c1_b_i2[c1_i10] = chartInstance->c1_i2[c1_i10];
  }

  c1_b_st.site = &c1_k_emlrtRSI;
  c1_c_imfilter(chartInstance, &c1_b_st, chartInstance->c1_b_i2,
                chartInstance->c1_i2);
  c1_x = chartInstance->c1_i1[0];
  c1_y = chartInstance->c1_i2[0];
  c1_c_a = c1_x;
  c1_b = c1_y;
  c1_b_x = c1_c_a;
  c1_b_y = c1_b;
  c1_x1 = c1_b_x;
  c1_x2 = c1_b_y;
  c1_d_a = c1_x1;
  c1_b_b = c1_x2;
  c1_r = muDoubleScalarHypot(c1_d_a, c1_b_b);
  chartInstance->c1_magGrad[0] = c1_r;
  c1_magmax = chartInstance->c1_magGrad[0];
  for (c1_idx = 0; c1_idx < 18643; c1_idx++) {
    c1_b_idx = (real_T)c1_idx + 2.0;
    c1_c_x = chartInstance->c1_i1[(int32_T)c1_b_idx - 1];
    c1_c_y = chartInstance->c1_i2[(int32_T)c1_b_idx - 1];
    c1_e_a = c1_c_x;
    c1_c_b = c1_c_y;
    c1_d_x = c1_e_a;
    c1_d_y = c1_c_b;
    c1_b_x1 = c1_d_x;
    c1_b_x2 = c1_d_y;
    c1_f_a = c1_b_x1;
    c1_d_b = c1_b_x2;
    c1_b_r = muDoubleScalarHypot(c1_f_a, c1_d_b);
    chartInstance->c1_magGrad[(int32_T)c1_b_idx - 1] = c1_b_r;
    c1_c_varargin_1 = chartInstance->c1_magGrad[(int32_T)c1_b_idx - 1];
    c1_varargin_2 = c1_magmax;
    c1_f_x = c1_c_varargin_1;
    c1_e_y = c1_varargin_2;
    c1_g_x = c1_f_x;
    c1_f_y = c1_e_y;
    c1_h_x = c1_g_x;
    c1_g_y = c1_f_y;
    c1_g_a = c1_h_x;
    c1_g_b = c1_g_y;
    c1_j_x = c1_g_a;
    c1_h_y = c1_g_b;
    c1_k_x = c1_j_x;
    c1_i_y = c1_h_y;
    c1_magmax = muDoubleScalarMax(c1_k_x, c1_i_y);
  }

  if (c1_magmax > 0.0) {
    for (c1_i11 = 0; c1_i11 < 18644; c1_i11++) {
      chartInstance->c1_magGrad[c1_i11] /= c1_magmax;
    }
  }

  c1_st.site = &c1_f_emlrtRSI;
  c1_b_st.site = &c1_s_emlrtRSI;
  c1_c_st.site = &c1_t_emlrtRSI;
  c1_d_st.site = &c1_u_emlrtRSI;
  c1_out = 1.0;
  getnumcores(&c1_out);
  for (c1_i12 = 0; c1_i12 < 64; c1_i12++) {
    c1_counts[c1_i12] = 0.0;
  }

  c1_nanFlag = false;
  for (c1_e_i = 0; c1_e_i < 18644; c1_e_i++) {
    c1_f_i = (real_T)c1_e_i + 1.0;
    c1_e_x = chartInstance->c1_magGrad[(int32_T)c1_f_i - 1];
    c1_e_b = muDoubleScalarIsNaN(c1_e_x);
    if (c1_e_b) {
      c1_nanFlag = true;
      c1_d_idx = 0.0;
    } else {
      c1_d_idx = chartInstance->c1_magGrad[(int32_T)c1_f_i - 1] * 63.0 + 0.5;
    }

    if (c1_d_idx > 63.0) {
      c1_counts[63]++;
    } else {
      c1_i_x = chartInstance->c1_magGrad[(int32_T)c1_f_i - 1];
      c1_f_b = muDoubleScalarIsInf(c1_i_x);
      if (c1_f_b) {
        c1_counts[63]++;
      } else {
        c1_h_a = c1_d_idx;
        c1_c = (int32_T)c1_h_a;
        c1_i_a = c1_d_idx;
        c1_b_c = (int32_T)c1_i_a;
        c1_counts[c1_c] = c1_counts[c1_b_c] + 1.0;
      }
    }
  }

  if (c1_nanFlag) {
    c1_d_st.site = &c1_v_emlrtRSI;
    c1_warning(chartInstance, &c1_d_st);
  }

  c1_sum = 0.0;
  c1_c_idx = 1;
  while ((!(c1_sum > 13050.8)) && ((real_T)c1_c_idx <= 64.0)) {
    c1_sum += c1_counts[c1_c_idx - 1];
    c1_i14 = c1_c_idx + 1;
    if (c1_i14 > 127) {
      c1_i14 = 127;
    } else if (c1_i14 < -128) {
      c1_i14 = -128;
    }

    c1_c_idx = (int8_T)c1_i14;
  }

  c1_i13 = c1_c_idx - 1;
  if (c1_i13 > 127) {
    c1_i13 = 127;
  } else if (c1_i13 < -128) {
    c1_i13 = -128;
  }

  c1_highThreshTemp = (real_T)(int8_T)c1_i13 / 64.0;
  if (((real_T)c1_c_idx > 64.0) && (!(c1_sum > 13050.8))) {
    c1_highThresh_size[0] = 0;
    c1_lowThresh_size[0] = 0;
  } else {
    c1_highThresh_size[0] = 1;
    c1_highThresh_data[0] = c1_highThreshTemp;
    c1_loop_ub = c1_highThresh_size[0] - 1;
    for (c1_i15 = 0; c1_i15 <= c1_loop_ub; c1_i15++) {
      c1_b_data[c1_i15] = c1_highThresh_data[c1_i15];
    }

    c1_b_data[0] *= 0.4;
    c1_lowThresh_size[0] = 1;
    c1_lowThresh_data[0] = c1_b_data[0];
  }

  c1_st.site = &c1_g_emlrtRSI;
  c1_i16 = 1;
  if ((c1_i16 < 1) || (c1_i16 > c1_lowThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c1_i16, 1, c1_lowThresh_size[0],
      &c1_d_emlrtBCI, &c1_st);
  }

  c1_b_st.site = &c1_x_emlrtRSI;
  c1_lowThresh = c1_lowThresh_data[0];
  c1_c_st.site = &c1_ab_emlrtRSI;
  c1_b_lowThresh = c1_lowThresh;
  for (c1_i17 = 0; c1_i17 < 18644; c1_i17++) {
    c1_E[c1_i17] = false;
  }

  for (c1_i18 = 0; c1_i18 < 2; c1_i18++) {
    c1_connDimsT[c1_i18] = 118.0 + 40.0 * (real_T)c1_i18;
  }

  cannythresholding_real64_tbb(&chartInstance->c1_i1[0], &chartInstance->c1_i2[0],
    &chartInstance->c1_magGrad[0], &c1_connDimsT[0], c1_b_lowThresh, &c1_E[0]);
  c1_i19 = 1;
  if ((c1_i19 < 1) || (c1_i19 > c1_highThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c1_i19, 1, c1_highThresh_size[0],
      &c1_c_emlrtBCI, &c1_st);
  }

  c1_highThresh = c1_highThresh_data[0];
  for (c1_i20 = 0; c1_i20 < 18644; c1_i20++) {
    c1_varargout_1[c1_i20] = (chartInstance->c1_magGrad[c1_i20] > c1_highThresh);
  }

  c1_b_st.site = &c1_y_emlrtRSI;
  c1_c_st.site = &c1_bb_emlrtRSI;
  c1_c_st.site = &c1_cb_emlrtRSI;
  for (c1_i21 = 0; c1_i21 < 2; c1_i21++) {
    c1_connDimsT[c1_i21] = 118.0 + 40.0 * (real_T)c1_i21;
  }

  ippreconstruct_uint8((uint8_T *)&c1_varargout_1[0], (uint8_T *)&c1_E[0],
                       &c1_connDimsT[0], 2.0);
  c1_i22 = 1;
  if ((c1_i22 < 1) || (c1_i22 > c1_lowThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c1_i22, 1, c1_lowThresh_size[0],
      &c1_f_emlrtBCI, (emlrtConstCTX)c1_sp);
  }

  c1_i23 = 1;
  if ((c1_i23 < 1) || (c1_i23 > c1_highThresh_size[0])) {
    emlrtDynamicBoundsCheckR2012b(c1_i23, 1, c1_highThresh_size[0],
      &c1_e_emlrtBCI, (emlrtConstCTX)c1_sp);
  }
}

static void c1_imfilter(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], real_T c1_b[18644])
{
  emlrtStack c1_b_st;
  emlrtStack c1_st;
  real_T c1_c_a[20060];
  real_T c1_connDimsT[2];
  real_T c1_outSizeT[2];
  real_T c1_padSizeT[2];
  real_T c1_startT[2];
  real_T c1_b_j;
  real_T c1_c_i;
  int32_T c1_b_i;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_d_i;
  int32_T c1_i;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i7;
  int32_T c1_j;
  boolean_T c1_b_modeFlag;
  boolean_T c1_c_modeFlag;
  boolean_T c1_modeFlag;
  boolean_T c1_tooBig;
  (void)chartInstance;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_st.site = &c1_l_emlrtRSI;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_b_st.site = &c1_n_emlrtRSI;
  for (c1_j = 0; c1_j < 170; c1_j++) {
    c1_b_j = (real_T)c1_j + 1.0;
    for (c1_i = 0; c1_i < 118; c1_i++) {
      c1_c_i = (real_T)c1_i + 1.0;
      if ((c1_iv1[(int32_T)c1_c_i - 1] < 1) || (c1_iv1[(int32_T)c1_c_i - 1] >
           118)) {
        emlrtDynamicBoundsCheckR2012b(c1_iv1[(int32_T)c1_c_i - 1], 1, 118,
          &c1_g_emlrtBCI, &c1_b_st);
      }

      c1_d_i = c1_iv1[(int32_T)c1_b_j + 169];
      if ((c1_d_i < 1) || (c1_d_i > 158)) {
        emlrtDynamicBoundsCheckR2012b(c1_d_i, 1, 158, &c1_h_emlrtBCI, &c1_b_st);
      }

      c1_c_a[((int32_T)c1_c_i + 118 * ((int32_T)c1_b_j - 1)) - 1] =
        c1_b_varargin_1[(c1_iv1[(int32_T)c1_c_i - 1] + 118 * (c1_d_i - 1)) - 1];
    }
  }

  c1_st.site = &c1_m_emlrtRSI;
  c1_tooBig = true;
  for (c1_b_i = 0; c1_b_i < 2; c1_b_i++) {
    c1_tooBig = false;
  }

  if (!c1_tooBig) {
    c1_modeFlag = true;
  } else {
    c1_modeFlag = false;
  }

  if (c1_modeFlag) {
    c1_b_modeFlag = true;
  } else {
    c1_b_modeFlag = false;
  }

  c1_c_modeFlag = c1_b_modeFlag;
  if (c1_c_modeFlag) {
    for (c1_c_i2 = 0; c1_c_i2 < 2; c1_c_i2++) {
      c1_padSizeT[c1_c_i2] = 118.0 + 52.0 * (real_T)c1_c_i2;
    }

    for (c1_i4 = 0; c1_i4 < 2; c1_i4++) {
      c1_outSizeT[c1_i4] = 118.0 + 40.0 * (real_T)c1_i4;
    }

    for (c1_i6 = 0; c1_i6 < 2; c1_i6++) {
      c1_connDimsT[c1_i6] = 1.0 + 12.0 * (real_T)c1_i6;
    }

    ippfilter_real64(&c1_c_a[0], &c1_b[0], &c1_outSizeT[0], 2.0, &c1_padSizeT[0],
                     &c1_dv1[0], &c1_connDimsT[0], true);
  } else {
    for (c1_c_i1 = 0; c1_c_i1 < 2; c1_c_i1++) {
      c1_padSizeT[c1_c_i1] = 118.0 + 52.0 * (real_T)c1_c_i1;
    }

    for (c1_i3 = 0; c1_i3 < 2; c1_i3++) {
      c1_outSizeT[c1_i3] = 118.0 + 40.0 * (real_T)c1_i3;
    }

    for (c1_i5 = 0; c1_i5 < 2; c1_i5++) {
      c1_connDimsT[c1_i5] = 1.0 + 12.0 * (real_T)c1_i5;
    }

    for (c1_i7 = 0; c1_i7 < 2; c1_i7++) {
      c1_startT[c1_i7] = 6.0 * (real_T)c1_i7;
    }

    imfilter_real64(&c1_c_a[0], &c1_b[0], 2.0, &c1_outSizeT[0], 2.0,
                    &c1_padSizeT[0], &c1_dv2[0], 12.0, &c1_bv[0], 2.0,
                    &c1_connDimsT[0], &c1_startT[0], 2.0, true, true);
  }
}

static void c1_b_imfilter(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], real_T c1_b[18644])
{
  emlrtStack c1_b_st;
  emlrtStack c1_st;
  real_T c1_c_a[20060];
  real_T c1_connDimsT[2];
  real_T c1_outSizeT[2];
  real_T c1_padSizeT[2];
  real_T c1_startT[2];
  real_T c1_b_j;
  real_T c1_c_i;
  int32_T c1_b_i;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_d_i;
  int32_T c1_i;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i7;
  int32_T c1_i8;
  int32_T c1_j;
  boolean_T c1_conn[13];
  boolean_T c1_b_modeFlag;
  boolean_T c1_c_modeFlag;
  boolean_T c1_modeFlag;
  boolean_T c1_tooBig;
  (void)chartInstance;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_st.site = &c1_l_emlrtRSI;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_b_st.site = &c1_n_emlrtRSI;
  for (c1_j = 0; c1_j < 170; c1_j++) {
    c1_b_j = (real_T)c1_j + 1.0;
    for (c1_i = 0; c1_i < 118; c1_i++) {
      c1_c_i = (real_T)c1_i + 1.0;
      if ((c1_iv1[(int32_T)c1_c_i - 1] < 1) || (c1_iv1[(int32_T)c1_c_i - 1] >
           118)) {
        emlrtDynamicBoundsCheckR2012b(c1_iv1[(int32_T)c1_c_i - 1], 1, 118,
          &c1_g_emlrtBCI, &c1_b_st);
      }

      c1_d_i = c1_iv1[(int32_T)c1_b_j + 169];
      if ((c1_d_i < 1) || (c1_d_i > 158)) {
        emlrtDynamicBoundsCheckR2012b(c1_d_i, 1, 158, &c1_h_emlrtBCI, &c1_b_st);
      }

      c1_c_a[((int32_T)c1_c_i + 118 * ((int32_T)c1_b_j - 1)) - 1] =
        c1_b_varargin_1[(c1_iv1[(int32_T)c1_c_i - 1] + 118 * (c1_d_i - 1)) - 1];
    }
  }

  c1_st.site = &c1_m_emlrtRSI;
  c1_tooBig = true;
  for (c1_b_i = 0; c1_b_i < 2; c1_b_i++) {
    c1_tooBig = false;
  }

  if (!c1_tooBig) {
    c1_modeFlag = true;
  } else {
    c1_modeFlag = false;
  }

  if (c1_modeFlag) {
    c1_b_modeFlag = true;
  } else {
    c1_b_modeFlag = false;
  }

  c1_c_modeFlag = c1_b_modeFlag;
  if (c1_c_modeFlag) {
    for (c1_c_i2 = 0; c1_c_i2 < 2; c1_c_i2++) {
      c1_padSizeT[c1_c_i2] = 118.0 + 52.0 * (real_T)c1_c_i2;
    }

    for (c1_i4 = 0; c1_i4 < 2; c1_i4++) {
      c1_outSizeT[c1_i4] = 118.0 + 40.0 * (real_T)c1_i4;
    }

    for (c1_i6 = 0; c1_i6 < 2; c1_i6++) {
      c1_connDimsT[c1_i6] = 1.0 + 12.0 * (real_T)c1_i6;
    }

    ippfilter_real64(&c1_c_a[0], &c1_b[0], &c1_outSizeT[0], 2.0, &c1_padSizeT[0],
                     &c1_dv[0], &c1_connDimsT[0], true);
  } else {
    for (c1_c_i1 = 0; c1_c_i1 < 13; c1_c_i1++) {
      c1_conn[c1_c_i1] = true;
    }

    for (c1_i3 = 0; c1_i3 < 2; c1_i3++) {
      c1_padSizeT[c1_i3] = 118.0 + 52.0 * (real_T)c1_i3;
    }

    for (c1_i5 = 0; c1_i5 < 2; c1_i5++) {
      c1_outSizeT[c1_i5] = 118.0 + 40.0 * (real_T)c1_i5;
    }

    for (c1_i7 = 0; c1_i7 < 2; c1_i7++) {
      c1_connDimsT[c1_i7] = 1.0 + 12.0 * (real_T)c1_i7;
    }

    for (c1_i8 = 0; c1_i8 < 2; c1_i8++) {
      c1_startT[c1_i8] = 6.0 * (real_T)c1_i8;
    }

    imfilter_real64(&c1_c_a[0], &c1_b[0], 2.0, &c1_outSizeT[0], 2.0,
                    &c1_padSizeT[0], &c1_dv[0], 13.0, &c1_conn[0], 2.0,
                    &c1_connDimsT[0], &c1_startT[0], 2.0, true, true);
  }
}

static void c1_c_imfilter(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[18644], real_T c1_b[18644])
{
  emlrtStack c1_b_st;
  emlrtStack c1_st;
  real_T c1_connDimsT[2];
  real_T c1_outSizeT[2];
  real_T c1_padSizeT[2];
  real_T c1_startT[2];
  real_T c1_b_j;
  real_T c1_c_i;
  int32_T c1_b_i;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_d_i;
  int32_T c1_i;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i7;
  int32_T c1_j;
  boolean_T c1_b_modeFlag;
  boolean_T c1_c_modeFlag;
  boolean_T c1_modeFlag;
  boolean_T c1_tooBig;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_st.site = &c1_l_emlrtRSI;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_b_st.site = &c1_n_emlrtRSI;
  for (c1_j = 0; c1_j < 158; c1_j++) {
    c1_b_j = (real_T)c1_j + 1.0;
    for (c1_i = 0; c1_i < 130; c1_i++) {
      c1_c_i = (real_T)c1_i + 1.0;
      if ((c1_iv[(int32_T)c1_c_i - 1] < 1) || (c1_iv[(int32_T)c1_c_i - 1] > 118))
      {
        emlrtDynamicBoundsCheckR2012b(c1_iv[(int32_T)c1_c_i - 1], 1, 118,
          &c1_g_emlrtBCI, &c1_b_st);
      }

      c1_d_i = c1_iv[(int32_T)c1_b_j + 157];
      if ((c1_d_i < 1) || (c1_d_i > 158)) {
        emlrtDynamicBoundsCheckR2012b(c1_d_i, 1, 158, &c1_h_emlrtBCI, &c1_b_st);
      }

      chartInstance->c1_b_a[((int32_T)c1_c_i + 130 * ((int32_T)c1_b_j - 1)) - 1]
        = c1_b_varargin_1[(c1_iv[(int32_T)c1_c_i - 1] + 118 * (c1_d_i - 1)) - 1];
    }
  }

  c1_st.site = &c1_m_emlrtRSI;
  c1_tooBig = true;
  for (c1_b_i = 0; c1_b_i < 2; c1_b_i++) {
    c1_tooBig = false;
  }

  if (!c1_tooBig) {
    c1_modeFlag = true;
  } else {
    c1_modeFlag = false;
  }

  if (c1_modeFlag) {
    c1_b_modeFlag = true;
  } else {
    c1_b_modeFlag = false;
  }

  c1_c_modeFlag = c1_b_modeFlag;
  if (c1_c_modeFlag) {
    for (c1_c_i2 = 0; c1_c_i2 < 2; c1_c_i2++) {
      c1_padSizeT[c1_c_i2] = 130.0 + 28.0 * (real_T)c1_c_i2;
    }

    for (c1_i4 = 0; c1_i4 < 2; c1_i4++) {
      c1_outSizeT[c1_i4] = 118.0 + 40.0 * (real_T)c1_i4;
    }

    for (c1_i6 = 0; c1_i6 < 2; c1_i6++) {
      c1_connDimsT[c1_i6] = 13.0 + -12.0 * (real_T)c1_i6;
    }

    ippfilter_real64(&chartInstance->c1_b_a[0], &c1_b[0], &c1_outSizeT[0], 2.0,
                     &c1_padSizeT[0], &c1_dv1[0], &c1_connDimsT[0], true);
  } else {
    for (c1_c_i1 = 0; c1_c_i1 < 2; c1_c_i1++) {
      c1_padSizeT[c1_c_i1] = 130.0 + 28.0 * (real_T)c1_c_i1;
    }

    for (c1_i3 = 0; c1_i3 < 2; c1_i3++) {
      c1_outSizeT[c1_i3] = 118.0 + 40.0 * (real_T)c1_i3;
    }

    for (c1_i5 = 0; c1_i5 < 2; c1_i5++) {
      c1_connDimsT[c1_i5] = 13.0 + -12.0 * (real_T)c1_i5;
    }

    for (c1_i7 = 0; c1_i7 < 2; c1_i7++) {
      c1_startT[c1_i7] = 6.0 + -6.0 * (real_T)c1_i7;
    }

    imfilter_real64(&chartInstance->c1_b_a[0], &c1_b[0], 2.0, &c1_outSizeT[0],
                    2.0, &c1_padSizeT[0], &c1_dv2[0], 12.0, &c1_bv[0], 2.0,
                    &c1_connDimsT[0], &c1_startT[0], 2.0, true, true);
  }
}

static void c1_warning(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp)
{
  static char_T c1_msgID[27] = { 'i', 'm', 'a', 'g', 'e', 's', ':', 'i', 'm',
    'h', 'i', 's', 't', 'c', ':', 'i', 'n', 'p', 'u', 't', 'H', 'a', 's', 'N',
    'a', 'N', 's' };

  static char_T c1_b_cv[7] = { 'w', 'a', 'r', 'n', 'i', 'n', 'g' };

  static char_T c1_b_cv1[7] = { 'm', 'e', 's', 's', 'a', 'g', 'e' };

  emlrtStack c1_st;
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_y = NULL;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1U, 0U, 2, 1, 7),
                false);
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_b_cv1, 10, 0U, 1U, 0U, 2, 1, 7),
                false);
  c1_c_y = NULL;
  sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_msgID, 10, 0U, 1U, 0U, 2, 1, 27),
                false);
  c1_st.site = &c1_w_emlrtRSI;
  c1_b_feval(chartInstance, &c1_st, c1_y, c1_feval(chartInstance, &c1_st, c1_b_y,
              c1_c_y));
}

static void c1_hough(SFc1_flightControlSystemInstanceStruct *chartInstance,
                     const emlrtStack *c1_sp, boolean_T c1_b_varargin_1[18644],
                     real_T c1_h[70740])
{
  emlrtStack c1_b_st;
  emlrtStack c1_st;
  real_T c1_cost[180];
  real_T c1_sint[180];
  real_T c1_tempBin[118];
  real_T c1_b_j;
  real_T c1_b_k;
  real_T c1_b_x;
  real_T c1_c_x;
  real_T c1_d_j;
  real_T c1_d_x;
  real_T c1_e_i;
  real_T c1_e_x;
  real_T c1_myRho;
  real_T c1_tempNum;
  real_T c1_x;
  int32_T c1_nonZeroPixelMatrix[18644];
  int32_T c1_rhoIdxVector[393];
  int32_T c1_numNonZeros[158];
  int32_T c1_b_i;
  int32_T c1_b_thetaIdx;
  int32_T c1_c;
  int32_T c1_c_a;
  int32_T c1_c_i;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_c_j;
  int32_T c1_d_i;
  int32_T c1_f_i;
  int32_T c1_i;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_j;
  int32_T c1_k;
  int32_T c1_n;
  int32_T c1_rhoIdx;
  int32_T c1_thetaIdx;
  int32_T c1_y;
  boolean_T c1_exitg1;
  (void)chartInstance;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_st.site = &c1_eb_emlrtRSI;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  for (c1_i = 0; c1_i < 180; c1_i++) {
    c1_b_i = c1_i;
    c1_x = (-90.0 + (real_T)c1_b_i) * 3.1415926535897931 / 180.0;
    c1_b_x = c1_x;
    c1_b_x = muDoubleScalarCos(c1_b_x);
    c1_cost[c1_b_i] = c1_b_x;
    c1_c_x = (-90.0 + (real_T)c1_b_i) * 3.1415926535897931 / 180.0;
    c1_d_x = c1_c_x;
    c1_d_x = muDoubleScalarSin(c1_d_x);
    c1_sint[c1_b_i] = c1_d_x;
  }

  c1_b_st.site = &c1_fb_emlrtRSI;
  for (c1_j = 0; c1_j < 158; c1_j++) {
    c1_b_j = (real_T)c1_j + 1.0;
    c1_tempNum = 0.0;
    for (c1_c_i = 0; c1_c_i < 118; c1_c_i++) {
      c1_e_i = (real_T)c1_c_i + 1.0;
      if (c1_b_varargin_1[((int32_T)c1_e_i + 118 * ((int32_T)c1_b_j - 1)) - 1])
      {
        c1_tempNum++;
        c1_c_i2 = (int32_T)c1_tempNum;
        if ((c1_c_i2 < 1) || (c1_c_i2 > 118)) {
          emlrtDynamicBoundsCheckR2012b(c1_c_i2, 1, 118, &c1_j_emlrtBCI,
            &c1_b_st);
        }

        c1_tempBin[c1_c_i2 - 1] = c1_e_i;
      }
    }

    c1_numNonZeros[(int32_T)c1_b_j - 1] = (int32_T)c1_tempNum;
    c1_k = 0;
    c1_exitg1 = false;
    while ((!c1_exitg1) && (c1_k < 118)) {
      c1_b_k = (real_T)c1_k + 1.0;
      if (c1_b_k > c1_tempNum) {
        c1_exitg1 = true;
      } else {
        c1_nonZeroPixelMatrix[((int32_T)c1_b_k + 118 * ((int32_T)c1_b_j - 1)) -
          1] = (int32_T)c1_tempBin[(int32_T)c1_b_k - 1];
        c1_k++;
      }
    }
  }

  for (c1_thetaIdx = 0; c1_thetaIdx < 180; c1_thetaIdx++) {
    c1_b_thetaIdx = c1_thetaIdx;
    for (c1_d_i = 0; c1_d_i < 393; c1_d_i++) {
      c1_rhoIdxVector[c1_d_i] = 0;
    }

    for (c1_c_j = 0; c1_c_j < 158; c1_c_j++) {
      c1_d_j = (real_T)c1_c_j + 1.0;
      c1_i3 = c1_numNonZeros[(int32_T)c1_d_j - 1];
      c1_i4 = (uint8_T)c1_i3 - 1;
      for (c1_f_i = 0; c1_f_i <= c1_i4; c1_f_i++) {
        c1_b_i = c1_f_i;
        c1_n = c1_nonZeroPixelMatrix[c1_b_i + 118 * ((int32_T)c1_d_j - 1)];
        c1_myRho = (c1_d_j - 1.0) * c1_cost[c1_b_thetaIdx] + ((real_T)c1_n - 1.0)
          * c1_sint[c1_b_thetaIdx];
        c1_e_x = c1_myRho - -196.0;
        c1_y = (int32_T)(c1_e_x + 0.5) + 1;
        c1_rhoIdx = c1_y;
        c1_c_a = c1_rhoIdxVector[c1_rhoIdx - 1] + 1;
        c1_c = c1_c_a;
        if ((c1_rhoIdx < 1) || (c1_rhoIdx > 393)) {
          emlrtDynamicBoundsCheckR2012b(c1_rhoIdx, 1, 393, &c1_i_emlrtBCI,
            &c1_st);
        }

        c1_rhoIdxVector[c1_rhoIdx - 1] = c1_c;
      }
    }

    for (c1_c_i1 = 0; c1_c_i1 < 393; c1_c_i1++) {
      c1_h[c1_c_i1 + 393 * c1_b_thetaIdx] = (real_T)c1_rhoIdxVector[c1_c_i1];
    }
  }
}

static void c1_houghpeaks(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, real_T c1_b_varargin_1[70740], real_T c1_peaks_data[],
  int32_T c1_peaks_size[2])
{
  static char_T c1_b_cv3[46] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o',
    'l', 'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't',
    't', 'r', 'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e',
    'd', 'N', 'o', 'n', 'N', 'a', 'N' };

  static char_T c1_cv6[43] = { 'i', 'm', 'a', 'g', 'e', 's', ':', 'h', 'o', 'u',
    'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'i', 'n', 'v', 'a', 'l', 'i', 'd',
    'T', 'h', 'e', 't', 'a', 'V', 'e', 'c', 't', 'o', 'r', 'S', 'p', 'a', 'c',
    'i', 'n', 'g' };

  static char_T c1_b_cv2[32] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o',
    'u', 'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't',
    'e', 'd', 'N', 'o', 'n', 'N', 'a', 'N' };

  static char_T c1_b_cv[18] = { 'i', 'n', 'p', 'u', 't', ' ', 'n', 'u', 'm', 'b',
    'e', 'r', ' ', '1', ',', ' ', 'H', ',' };

  static char_T c1_b_cv1[18] = { 'i', 'n', 'p', 'u', 't', ' ', 'n', 'u', 'm',
    'b', 'e', 'r', ' ', '1', ',', ' ', 'H', ',' };

  static char_T c1_cv4[9] = { 'T', 'h', 'r', 'e', 's', 'h', 'o', 'l', 'd' };

  static char_T c1_cv5[5] = { 'T', 'h', 'e', 't', 'a' };

  emlrtStack c1_b_st;
  emlrtStack c1_c_st;
  emlrtStack c1_d_st;
  emlrtStack c1_st;
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  const mxArray *c1_e_y = NULL;
  const mxArray *c1_f_y = NULL;
  const mxArray *c1_g_y = NULL;
  const mxArray *c1_h_y = NULL;
  const mxArray *c1_i_y = NULL;
  const mxArray *c1_j_y = NULL;
  const mxArray *c1_k_y = NULL;
  const mxArray *c1_l_y = NULL;
  const mxArray *c1_o_y = NULL;
  const mxArray *c1_p_y = NULL;
  const mxArray *c1_y = NULL;
  real_T c1_b_dv1[180];
  real_T c1_thetaInterval[179];
  real_T c1_o_x[178];
  real_T c1_peakCoordinates[4];
  real_T c1_c_dv[2];
  real_T c1_ab_x;
  real_T c1_b_default;
  real_T c1_b_ex;
  real_T c1_b_k;
  real_T c1_b_ndx;
  real_T c1_b_threshold;
  real_T c1_b_thresholdDefault;
  real_T c1_b_x;
  real_T c1_bb_x;
  real_T c1_c_a;
  real_T c1_c_ex;
  real_T c1_c_threshold;
  real_T c1_c_x;
  real_T c1_cb_x;
  real_T c1_d_a;
  real_T c1_d_k;
  real_T c1_d_x;
  real_T c1_default;
  real_T c1_e_a;
  real_T c1_e_idx;
  real_T c1_e_x;
  real_T c1_ex;
  real_T c1_f_k;
  real_T c1_f_x;
  real_T c1_g_x;
  real_T c1_h_k;
  real_T c1_h_x;
  real_T c1_iPeak;
  real_T c1_i_x;
  real_T c1_jPeak;
  real_T c1_j_x;
  real_T c1_k_x;
  real_T c1_l_x;
  real_T c1_m_x;
  real_T c1_m_y;
  real_T c1_maxTheta;
  real_T c1_maxVal;
  real_T c1_minTheta;
  real_T c1_n_x;
  real_T c1_n_y;
  real_T c1_ndx;
  real_T c1_p_x;
  real_T c1_q_x;
  real_T c1_q_y;
  real_T c1_r_x;
  real_T c1_r_y;
  real_T c1_s_x;
  real_T c1_t_x;
  real_T c1_thetaResolution;
  real_T c1_threshold;
  real_T c1_thresholdDefault;
  real_T c1_u_x;
  real_T c1_v_x;
  real_T c1_val;
  real_T c1_w_x;
  real_T c1_x;
  real_T c1_x_x;
  real_T c1_y_x;
  int32_T c1_b_iPeak;
  int32_T c1_b_idx;
  int32_T c1_b_jPeak;
  int32_T c1_c_i1;
  int32_T c1_c_i2;
  int32_T c1_c_idx;
  int32_T c1_c_k;
  int32_T c1_d_idx;
  int32_T c1_e_k;
  int32_T c1_f_a;
  int32_T c1_f_idx;
  int32_T c1_first;
  int32_T c1_g_k;
  int32_T c1_i;
  int32_T c1_i3;
  int32_T c1_i4;
  int32_T c1_i5;
  int32_T c1_i6;
  int32_T c1_i_k;
  int32_T c1_idx;
  int32_T c1_iindx;
  int32_T c1_j_k;
  int32_T c1_k;
  int32_T c1_k_k;
  int32_T c1_l_k;
  int32_T c1_loop_ub;
  int32_T c1_peakIdx;
  int32_T c1_rho;
  int32_T c1_rhoMax;
  int32_T c1_rhoMin;
  int32_T c1_rhoToRemove;
  int32_T c1_theta;
  int32_T c1_thetaMax;
  int32_T c1_thetaMin;
  int32_T c1_thetaToRemove;
  int32_T c1_v1;
  int32_T c1_varargout_3;
  int32_T c1_varargout_4;
  int32_T c1_vk;
  boolean_T c1_b;
  boolean_T c1_b1;
  boolean_T c1_b2;
  boolean_T c1_b3;
  boolean_T c1_b4;
  boolean_T c1_b5;
  boolean_T c1_b6;
  boolean_T c1_b7;
  boolean_T c1_b8;
  boolean_T c1_b9;
  boolean_T c1_b_b;
  boolean_T c1_b_p;
  boolean_T c1_c_b;
  boolean_T c1_c_p;
  boolean_T c1_d_b;
  boolean_T c1_d_p;
  boolean_T c1_e_b;
  boolean_T c1_e_p;
  boolean_T c1_exitg1;
  boolean_T c1_f_b;
  boolean_T c1_f_p;
  boolean_T c1_g_b;
  boolean_T c1_g_p;
  boolean_T c1_h_b;
  boolean_T c1_h_p;
  boolean_T c1_i_b;
  boolean_T c1_i_p;
  boolean_T c1_isDone;
  boolean_T c1_isThetaAntisymmetric;
  boolean_T c1_j_b;
  boolean_T c1_k_b;
  boolean_T c1_l_b;
  boolean_T c1_m_b;
  boolean_T c1_p;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_b_st.prev = &c1_st;
  c1_b_st.tls = c1_st.tls;
  c1_c_st.prev = &c1_b_st;
  c1_c_st.tls = c1_b_st.tls;
  c1_d_st.prev = &c1_c_st;
  c1_d_st.tls = c1_c_st.tls;
  c1_st.site = &c1_hb_emlrtRSI;
  c1_b_st.site = &c1_ib_emlrtRSI;
  c1_c_st.site = &c1_mb_emlrtRSI;
  c1_p = true;
  c1_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_k < 70740)) {
    c1_b_k = (real_T)c1_k + 1.0;
    c1_x = c1_b_varargin_1[(int32_T)c1_b_k - 1];
    c1_b_x = c1_x;
    c1_b_b = muDoubleScalarIsInf(c1_b_x);
    c1_b1 = !c1_b_b;
    c1_c_x = c1_x;
    c1_c_b = muDoubleScalarIsNaN(c1_c_x);
    c1_b2 = !c1_c_b;
    c1_d_b = (c1_b1 && c1_b2);
    if (c1_d_b) {
      c1_k++;
    } else {
      c1_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_p) {
    c1_b = true;
  } else {
    c1_b = false;
  }

  if (!c1_b) {
    c1_y = NULL;
    sf_mex_assign(&c1_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 32),
                  false);
    c1_b_y = NULL;
    sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv1, 10, 0U, 1U, 0U, 2, 1, 46),
                  false);
    c1_c_y = NULL;
    sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1U, 0U, 2, 1, 18),
                  false);
    sf_mex_call(&c1_c_st, &c1_d_emlrtMCI, "error", 0U, 2U, 14, c1_y, 14,
                sf_mex_call(&c1_c_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_c_st, NULL, "message", 1U, 2U, 14, c1_b_y, 14, c1_c_y)));
  }

  c1_c_st.site = &c1_mb_emlrtRSI;
  c1_b_p = true;
  c1_c_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_c_k < 70740)) {
    c1_d_k = (real_T)c1_c_k + 1.0;
    c1_d_x = c1_b_varargin_1[(int32_T)c1_d_k - 1];
    c1_e_x = c1_d_x;
    c1_f_x = c1_e_x;
    c1_e_b = muDoubleScalarIsInf(c1_f_x);
    c1_b4 = !c1_e_b;
    c1_g_x = c1_e_x;
    c1_f_b = muDoubleScalarIsNaN(c1_g_x);
    c1_b5 = !c1_f_b;
    c1_g_b = (c1_b4 && c1_b5);
    if (c1_g_b) {
      c1_h_x = c1_d_x;
      c1_i_x = c1_h_x;
      if (c1_i_x == c1_d_x) {
        c1_c_p = true;
      } else {
        c1_c_p = false;
      }
    } else {
      c1_c_p = false;
    }

    c1_d_p = c1_c_p;
    if (c1_d_p) {
      c1_c_k++;
    } else {
      c1_b_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_b_p) {
    c1_b3 = true;
  } else {
    c1_b3 = false;
  }

  if (!c1_b3) {
    c1_d_y = NULL;
    sf_mex_assign(&c1_d_y, sf_mex_create("y", c1_cv2, 10, 0U, 1U, 0U, 2, 1, 33),
                  false);
    c1_e_y = NULL;
    sf_mex_assign(&c1_e_y, sf_mex_create("y", c1_cv3, 10, 0U, 1U, 0U, 2, 1, 47),
                  false);
    c1_f_y = NULL;
    sf_mex_assign(&c1_f_y, sf_mex_create("y", c1_b_cv1, 10, 0U, 1U, 0U, 2, 1, 18),
                  false);
    sf_mex_call(&c1_c_st, &c1_e_emlrtMCI, "error", 0U, 2U, 14, c1_d_y, 14,
                sf_mex_call(&c1_c_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_c_st, NULL, "message", 1U, 2U, 14, c1_e_y, 14, c1_f_y)));
  }

  c1_maxVal = 0.0;
  for (c1_e_k = 0; c1_e_k < 70740; c1_e_k++) {
    c1_f_k = (real_T)c1_e_k + 1.0;
    c1_val = c1_b_varargin_1[(int32_T)c1_f_k - 1];
    if (c1_val > c1_maxVal) {
      c1_maxVal = c1_val;
    }
  }

  c1_thresholdDefault = 0.5 * c1_maxVal;
  c1_b_thresholdDefault = c1_thresholdDefault;
  c1_default = c1_b_thresholdDefault;
  c1_b_default = c1_default;
  c1_threshold = c1_b_default;
  c1_b_threshold = c1_threshold;
  c1_b_st.site = &c1_jb_emlrtRSI;
  c1_c_threshold = c1_threshold;
  c1_c_st.site = &c1_nb_emlrtRSI;
  c1_c_a = c1_c_threshold;
  c1_d_st.site = &c1_mb_emlrtRSI;
  c1_d_a = c1_c_a;
  c1_e_a = c1_d_a;
  c1_e_p = true;
  c1_j_x = c1_e_a;
  c1_k_x = c1_j_x;
  c1_h_b = muDoubleScalarIsNaN(c1_k_x);
  c1_f_p = !c1_h_b;
  if (!c1_f_p) {
    c1_e_p = false;
  }

  if (c1_e_p) {
    c1_b6 = true;
  } else {
    c1_b6 = false;
  }

  if (!c1_b6) {
    c1_g_y = NULL;
    sf_mex_assign(&c1_g_y, sf_mex_create("y", c1_b_cv2, 10, 0U, 1U, 0U, 2, 1, 32),
                  false);
    c1_h_y = NULL;
    sf_mex_assign(&c1_h_y, sf_mex_create("y", c1_b_cv3, 10, 0U, 1U, 0U, 2, 1, 46),
                  false);
    c1_i_y = NULL;
    sf_mex_assign(&c1_i_y, sf_mex_create("y", c1_cv4, 10, 0U, 1U, 0U, 2, 1, 9),
                  false);
    sf_mex_call(&c1_d_st, &c1_f_emlrtMCI, "error", 0U, 2U, 14, c1_g_y, 14,
                sf_mex_call(&c1_d_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_d_st, NULL, "message", 1U, 2U, 14, c1_h_y, 14, c1_i_y)));
  }

  c1_b_st.site = &c1_kb_emlrtRSI;
  for (c1_i = 0; c1_i < 2; c1_i++) {
    c1_c_dv[c1_i] = 9.0 + -4.0 * (real_T)c1_i;
  }

  c1_c_st.site = &c1_ob_emlrtRSI;
  c1_validateattributes(chartInstance, &c1_c_st, c1_c_dv);
  c1_b_st.site = &c1_lb_emlrtRSI;
  c1_c_st.site = &c1_qb_emlrtRSI;
  c1_d_st.site = &c1_mb_emlrtRSI;
  c1_g_p = true;
  c1_g_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_g_k < 180)) {
    c1_h_k = (real_T)c1_g_k + 1.0;
    c1_l_x = -90.0 + (real_T)((int32_T)c1_h_k - 1);
    c1_m_x = c1_l_x;
    c1_i_b = muDoubleScalarIsInf(c1_m_x);
    c1_b8 = !c1_i_b;
    c1_n_x = c1_l_x;
    c1_j_b = muDoubleScalarIsNaN(c1_n_x);
    c1_b9 = !c1_j_b;
    c1_k_b = (c1_b8 && c1_b9);
    if (c1_k_b) {
      c1_g_k++;
    } else {
      c1_g_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_g_p) {
    c1_b7 = true;
  } else {
    c1_b7 = false;
  }

  if (!c1_b7) {
    c1_j_y = NULL;
    sf_mex_assign(&c1_j_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 32),
                  false);
    c1_k_y = NULL;
    sf_mex_assign(&c1_k_y, sf_mex_create("y", c1_cv1, 10, 0U, 1U, 0U, 2, 1, 46),
                  false);
    c1_l_y = NULL;
    sf_mex_assign(&c1_l_y, sf_mex_create("y", c1_cv5, 10, 0U, 1U, 0U, 2, 1, 5),
                  false);
    sf_mex_call(&c1_d_st, &c1_d_emlrtMCI, "error", 0U, 2U, 14, c1_j_y, 14,
                sf_mex_call(&c1_d_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_d_st, NULL, "message", 1U, 2U, 14, c1_k_y, 14, c1_l_y)));
  }

  for (c1_c_i1 = 0; c1_c_i1 < 180; c1_c_i1++) {
    c1_b_dv1[c1_c_i1] = -90.0 + (real_T)c1_c_i1;
  }

  c1_diff(chartInstance, c1_b_dv1, c1_thetaInterval);
  c1_c_st.site = &c1_pb_emlrtRSI;
  c1_b_diff(chartInstance, c1_thetaInterval, c1_o_x);
  c1_m_y = c1_sumColumnB(chartInstance, c1_o_x);
  c1_p_x = c1_m_y;
  c1_q_x = c1_p_x;
  c1_r_x = c1_q_x;
  c1_n_y = muDoubleScalarAbs(c1_r_x);
  if (c1_n_y > 1.4901161193847656E-8) {
    c1_o_y = NULL;
    sf_mex_assign(&c1_o_y, sf_mex_create("y", c1_cv6, 10, 0U, 1U, 0U, 2, 1, 43),
                  false);
    c1_p_y = NULL;
    sf_mex_assign(&c1_p_y, sf_mex_create("y", c1_cv6, 10, 0U, 1U, 0U, 2, 1, 43),
                  false);
    sf_mex_call(&c1_b_st, &c1_j_emlrtMCI, "error", 0U, 2U, 14, c1_o_y, 14,
                sf_mex_call(&c1_b_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_b_st, NULL, "message", 1U, 1U, 14, c1_p_y)));
  }

  c1_isDone = false;
  for (c1_c_i2 = 0; c1_c_i2 < 70740; c1_c_i2++) {
    chartInstance->c1_hnew[c1_c_i2] = c1_b_varargin_1[c1_c_i2];
  }

  c1_peakIdx = 0;
  c1_ex = -90.0;
  for (c1_i_k = 0; c1_i_k < 179; c1_i_k++) {
    if (c1_ex > -90.0 + (real_T)(c1_i_k + 1)) {
      c1_ex = -90.0 + (real_T)(c1_i_k + 1);
    }
  }

  c1_minTheta = c1_ex;
  c1_b_ex = -90.0;
  for (c1_j_k = 0; c1_j_k < 179; c1_j_k++) {
    if (c1_b_ex < -90.0 + (real_T)(c1_j_k + 1)) {
      c1_b_ex = -90.0 + (real_T)(c1_j_k + 1);
    }
  }

  c1_maxTheta = c1_b_ex;
  c1_s_x = c1_maxTheta - c1_minTheta;
  c1_t_x = c1_s_x;
  c1_u_x = c1_t_x;
  c1_q_y = muDoubleScalarAbs(c1_u_x);
  c1_thetaResolution = c1_q_y / 179.0;
  c1_v_x = c1_minTheta + c1_thetaResolution * 5.0;
  c1_w_x = c1_v_x;
  c1_x_x = c1_w_x;
  c1_r_y = muDoubleScalarAbs(c1_x_x);
  c1_isThetaAntisymmetric = (c1_r_y <= c1_maxTheta);
  while (!c1_isDone) {
    for (c1_i3 = 0; c1_i3 < 70740; c1_i3++) {
      chartInstance->c1_varargin_1[c1_i3] = chartInstance->c1_hnew[c1_i3];
    }

    c1_y_x = chartInstance->c1_varargin_1[0];
    c1_ab_x = c1_y_x;
    c1_l_b = muDoubleScalarIsNaN(c1_ab_x);
    c1_h_p = !c1_l_b;
    if (c1_h_p) {
      c1_idx = 1;
    } else {
      c1_idx = 0;
      c1_k_k = 2;
      c1_exitg1 = false;
      while ((!c1_exitg1) && (c1_k_k < 70741)) {
        c1_bb_x = chartInstance->c1_varargin_1[c1_k_k - 1];
        c1_cb_x = c1_bb_x;
        c1_m_b = muDoubleScalarIsNaN(c1_cb_x);
        c1_i_p = !c1_m_b;
        if (c1_i_p) {
          c1_idx = c1_k_k;
          c1_exitg1 = true;
        } else {
          c1_k_k++;
        }
      }
    }

    if (c1_idx == 0) {
      c1_idx = 1;
    } else {
      c1_first = c1_idx;
      c1_c_ex = chartInstance->c1_varargin_1[c1_first - 1];
      c1_b_idx = c1_first;
      c1_i6 = c1_first;
      for (c1_l_k = c1_i6 + 1; c1_l_k < 70741; c1_l_k++) {
        if (c1_c_ex < chartInstance->c1_varargin_1[c1_l_k - 1]) {
          c1_c_ex = chartInstance->c1_varargin_1[c1_l_k - 1];
          c1_b_idx = c1_l_k;
        }
      }

      c1_idx = c1_b_idx;
    }

    c1_c_idx = c1_idx;
    c1_d_idx = c1_c_idx;
    c1_iindx = c1_d_idx;
    c1_e_idx = (real_T)c1_iindx;
    c1_st.site = &c1_gb_emlrtRSI;
    c1_ndx = c1_e_idx;
    c1_b_st.site = &c1_rb_emlrtRSI;
    c1_b_ndx = c1_ndx;
    c1_f_idx = (int32_T)c1_b_ndx - 1;
    c1_v1 = c1_f_idx;
    c1_f_a = c1_v1;
    c1_vk = (int32_T)((uint32_T)c1_f_a / 393U);
    c1_varargout_4 = c1_vk;
    c1_v1 = (c1_v1 - c1_vk * 393) + 1;
    c1_varargout_3 = c1_v1;
    c1_iPeak = (real_T)c1_varargout_3;
    c1_jPeak = (real_T)(c1_varargout_4 + 1);
    c1_b_iPeak = (int32_T)c1_iPeak;
    c1_b_jPeak = (int32_T)c1_jPeak;
    if ((c1_b_iPeak < 1) || (c1_b_iPeak > 393)) {
      emlrtDynamicBoundsCheckR2012b(c1_b_iPeak, 1, 393, &c1_l_emlrtBCI,
        (emlrtConstCTX)c1_sp);
    }

    if (chartInstance->c1_hnew[(c1_b_iPeak + 393 * (c1_b_jPeak - 1)) - 1] >=
        c1_b_threshold) {
      c1_peakIdx++;
      if ((c1_peakIdx < 1) || (c1_peakIdx > 2)) {
        emlrtDynamicBoundsCheckR2012b(c1_peakIdx, 1, 2, &c1_k_emlrtBCI,
          (emlrtConstCTX)c1_sp);
      }

      c1_peakCoordinates[c1_peakIdx - 1] = (real_T)c1_b_iPeak;
      c1_peakCoordinates[c1_peakIdx + 1] = (real_T)c1_b_jPeak;
      c1_rhoMin = c1_b_iPeak - 4;
      c1_rhoMax = c1_b_iPeak + 4;
      c1_thetaMin = c1_b_jPeak;
      c1_thetaMax = c1_b_jPeak;
      if (c1_rhoMin < 1) {
        c1_rhoMin = 1;
      }

      if (c1_rhoMax > 393) {
        c1_rhoMax = 393;
      }

      for (c1_theta = c1_thetaMin - 2; c1_theta <= c1_thetaMax + 2; c1_theta++)
      {
        for (c1_rho = c1_rhoMin; c1_rho <= c1_rhoMax; c1_rho++) {
          c1_rhoToRemove = c1_rho;
          c1_thetaToRemove = c1_theta;
          if (c1_isThetaAntisymmetric) {
            if (c1_theta > 180) {
              c1_rhoToRemove = 394 - c1_rho;
              c1_thetaToRemove = c1_theta - 180;
            } else if (c1_theta < 1) {
              c1_rhoToRemove = 394 - c1_rho;
              c1_thetaToRemove = c1_theta + 180;
            }
          }

          if ((c1_thetaToRemove > 180) || (c1_thetaToRemove < 1)) {
          } else {
            chartInstance->c1_hnew[(c1_rhoToRemove + 393 * (c1_thetaToRemove - 1))
              - 1] = 0.0;
          }
        }
      }

      c1_isDone = (c1_peakIdx == 2);
    } else {
      c1_isDone = true;
    }
  }

  if (c1_peakIdx == 0) {
    c1_peaks_size[0] = 0;
    c1_peaks_size[1] = 0;
  } else {
    c1_peaks_size[0] = c1_peakIdx;
    c1_peaks_size[1] = 2;
    for (c1_i4 = 0; c1_i4 < 2; c1_i4++) {
      c1_loop_ub = c1_peakIdx - 1;
      for (c1_i5 = 0; c1_i5 <= c1_loop_ub; c1_i5++) {
        c1_peaks_data[c1_i5 + c1_peaks_size[0] * c1_i4] =
          c1_peakCoordinates[c1_i5 + (c1_i4 << 1)];
      }
    }
  }
}

static void c1_validateattributes(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c1_sp, real_T c1_c_a[2])
{
  static char_T c1_b_cv3[43] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o',
    'l', 'b', 'o', 'x', ':', 'V', 'a', 'l', 'i', 'd', 'a', 't', 'e', 'a', 't',
    't', 'r', 'i', 'b', 'u', 't', 'e', 's', 'e', 'x', 'p', 'e', 'c', 't', 'e',
    'd', 'O', 'd', 'd' };

  static char_T c1_b_cv2[29] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'h', 'o',
    'u', 'g', 'h', 'p', 'e', 'a', 'k', 's', ':', 'e', 'x', 'p', 'e', 'c', 't',
    'e', 'd', 'O', 'd', 'd' };

  static char_T c1_b_cv[9] = { 'N', 'H', 'o', 'o', 'd', 'S', 'i', 'z', 'e' };

  static char_T c1_b_cv1[9] = { 'N', 'H', 'o', 'o', 'd', 'S', 'i', 'z', 'e' };

  static char_T c1_cv4[9] = { 'N', 'H', 'o', 'o', 'd', 'S', 'i', 'z', 'e' };

  emlrtStack c1_st;
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  const mxArray *c1_e_y = NULL;
  const mxArray *c1_f_y = NULL;
  const mxArray *c1_g_y = NULL;
  const mxArray *c1_h_y = NULL;
  const mxArray *c1_i_y = NULL;
  const mxArray *c1_y = NULL;
  real_T c1_b_k;
  real_T c1_b_x;
  real_T c1_c_x;
  real_T c1_d_a;
  real_T c1_d_k;
  real_T c1_d_x;
  real_T c1_e_x;
  real_T c1_f_k;
  real_T c1_f_x;
  real_T c1_g_x;
  real_T c1_h_x;
  real_T c1_i_x;
  real_T c1_j_x;
  real_T c1_k_x;
  real_T c1_l_x;
  real_T c1_m_x;
  real_T c1_n_x;
  real_T c1_o_x;
  real_T c1_r;
  real_T c1_x;
  int32_T c1_c_k;
  int32_T c1_e_k;
  int32_T c1_k;
  boolean_T c1_b;
  boolean_T c1_b1;
  boolean_T c1_b2;
  boolean_T c1_b3;
  boolean_T c1_b4;
  boolean_T c1_b5;
  boolean_T c1_b6;
  boolean_T c1_b_b;
  boolean_T c1_b_p;
  boolean_T c1_c_b;
  boolean_T c1_c_p;
  boolean_T c1_d_b;
  boolean_T c1_d_p;
  boolean_T c1_e_b;
  boolean_T c1_e_p;
  boolean_T c1_exitg1;
  boolean_T c1_f_b;
  boolean_T c1_f_p;
  boolean_T c1_g_b;
  boolean_T c1_h_b;
  boolean_T c1_i_b;
  boolean_T c1_p;
  boolean_T c1_rEQ0;
  (void)chartInstance;
  c1_st.prev = c1_sp;
  c1_st.tls = c1_sp->tls;
  c1_st.site = &c1_mb_emlrtRSI;
  c1_p = true;
  c1_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_k < 2)) {
    c1_b_k = (real_T)c1_k + 1.0;
    c1_x = c1_c_a[(int32_T)c1_b_k - 1];
    c1_b_x = c1_x;
    c1_b_b = muDoubleScalarIsInf(c1_b_x);
    c1_b1 = !c1_b_b;
    c1_c_x = c1_x;
    c1_c_b = muDoubleScalarIsNaN(c1_c_x);
    c1_b2 = !c1_c_b;
    c1_d_b = (c1_b1 && c1_b2);
    if (c1_d_b) {
      c1_k++;
    } else {
      c1_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_p) {
    c1_b = true;
  } else {
    c1_b = false;
  }

  if (!c1_b) {
    c1_y = NULL;
    sf_mex_assign(&c1_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 32),
                  false);
    c1_b_y = NULL;
    sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv1, 10, 0U, 1U, 0U, 2, 1, 46),
                  false);
    c1_c_y = NULL;
    sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_b_cv, 10, 0U, 1U, 0U, 2, 1, 9),
                  false);
    sf_mex_call(&c1_st, &c1_d_emlrtMCI, "error", 0U, 2U, 14, c1_y, 14,
                sf_mex_call(&c1_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_st, NULL, "message", 1U, 2U, 14, c1_b_y, 14, c1_c_y)));
  }

  c1_st.site = &c1_mb_emlrtRSI;
  c1_b_p = true;
  c1_c_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_c_k < 2)) {
    c1_d_k = (real_T)c1_c_k + 1.0;
    c1_d_x = c1_c_a[(int32_T)c1_d_k - 1];
    c1_e_x = c1_d_x;
    c1_f_x = c1_e_x;
    c1_e_b = muDoubleScalarIsInf(c1_f_x);
    c1_b4 = !c1_e_b;
    c1_g_x = c1_e_x;
    c1_f_b = muDoubleScalarIsNaN(c1_g_x);
    c1_b5 = !c1_f_b;
    c1_g_b = (c1_b4 && c1_b5);
    if (c1_g_b) {
      c1_h_x = c1_d_x;
      c1_i_x = c1_h_x;
      if (c1_i_x == c1_d_x) {
        c1_d_p = true;
      } else {
        c1_d_p = false;
      }
    } else {
      c1_d_p = false;
    }

    c1_e_p = c1_d_p;
    if (c1_e_p) {
      c1_c_k++;
    } else {
      c1_b_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_b_p) {
    c1_b3 = true;
  } else {
    c1_b3 = false;
  }

  if (!c1_b3) {
    c1_d_y = NULL;
    sf_mex_assign(&c1_d_y, sf_mex_create("y", c1_cv2, 10, 0U, 1U, 0U, 2, 1, 33),
                  false);
    c1_e_y = NULL;
    sf_mex_assign(&c1_e_y, sf_mex_create("y", c1_cv3, 10, 0U, 1U, 0U, 2, 1, 47),
                  false);
    c1_f_y = NULL;
    sf_mex_assign(&c1_f_y, sf_mex_create("y", c1_b_cv1, 10, 0U, 1U, 0U, 2, 1, 9),
                  false);
    sf_mex_call(&c1_st, &c1_e_emlrtMCI, "error", 0U, 2U, 14, c1_d_y, 14,
                sf_mex_call(&c1_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_st, NULL, "message", 1U, 2U, 14, c1_e_y, 14, c1_f_y)));
  }

  c1_st.site = &c1_mb_emlrtRSI;
  c1_st.site = &c1_mb_emlrtRSI;
  c1_c_p = true;
  c1_e_k = 0;
  c1_exitg1 = false;
  while ((!c1_exitg1) && (c1_e_k < 2)) {
    c1_f_k = (real_T)c1_e_k + 1.0;
    c1_j_x = c1_c_a[(int32_T)c1_f_k - 1];
    c1_k_x = c1_j_x;
    c1_d_a = c1_k_x;
    c1_l_x = c1_d_a;
    c1_m_x = c1_l_x;
    c1_n_x = c1_m_x;
    c1_h_b = muDoubleScalarIsNaN(c1_n_x);
    if (c1_h_b) {
      c1_r = rtNaN;
    } else {
      c1_o_x = c1_m_x;
      c1_i_b = muDoubleScalarIsInf(c1_o_x);
      if (c1_i_b) {
        c1_r = rtNaN;
      } else {
        c1_r = muDoubleScalarRem(c1_m_x, 2.0);
        c1_rEQ0 = (c1_r == 0.0);
        if (c1_rEQ0) {
          c1_r = 0.0;
        }
      }
    }

    c1_f_p = (c1_r == 1.0);
    if (c1_f_p) {
      c1_e_k++;
    } else {
      c1_c_p = false;
      c1_exitg1 = true;
    }
  }

  if (c1_c_p) {
    c1_b6 = true;
  } else {
    c1_b6 = false;
  }

  if (!c1_b6) {
    c1_g_y = NULL;
    sf_mex_assign(&c1_g_y, sf_mex_create("y", c1_b_cv2, 10, 0U, 1U, 0U, 2, 1, 29),
                  false);
    c1_h_y = NULL;
    sf_mex_assign(&c1_h_y, sf_mex_create("y", c1_b_cv3, 10, 0U, 1U, 0U, 2, 1, 43),
                  false);
    c1_i_y = NULL;
    sf_mex_assign(&c1_i_y, sf_mex_create("y", c1_cv4, 10, 0U, 1U, 0U, 2, 1, 9),
                  false);
    sf_mex_call(&c1_st, &c1_i_emlrtMCI, "error", 0U, 2U, 14, c1_g_y, 14,
                sf_mex_call(&c1_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c1_st, NULL, "message", 1U, 2U, 14, c1_h_y, 14, c1_i_y)));
  }
}

static void c1_diff(SFc1_flightControlSystemInstanceStruct *chartInstance,
                    real_T c1_x[180], real_T c1_y[179])
{
  real_T c1_tmp1;
  real_T c1_tmp2;
  real_T c1_work;
  int32_T c1_ixLead;
  int32_T c1_iyLead;
  int32_T c1_m;
  (void)chartInstance;
  c1_ixLead = 1;
  c1_iyLead = 0;
  c1_work = c1_x[0];
  for (c1_m = 0; c1_m < 179; c1_m++) {
    c1_tmp1 = c1_x[c1_ixLead];
    c1_tmp2 = c1_work;
    c1_work = c1_tmp1;
    c1_tmp1 -= c1_tmp2;
    c1_ixLead++;
    c1_y[c1_iyLead] = c1_tmp1;
    c1_iyLead++;
  }
}

static void c1_b_diff(SFc1_flightControlSystemInstanceStruct *chartInstance,
                      real_T c1_x[179], real_T c1_y[178])
{
  real_T c1_tmp1;
  real_T c1_tmp2;
  real_T c1_work;
  int32_T c1_ixLead;
  int32_T c1_iyLead;
  int32_T c1_m;
  (void)chartInstance;
  c1_ixLead = 1;
  c1_iyLead = 0;
  c1_work = c1_x[0];
  for (c1_m = 0; c1_m < 178; c1_m++) {
    c1_tmp1 = c1_x[c1_ixLead];
    c1_tmp2 = c1_work;
    c1_work = c1_tmp1;
    c1_tmp1 -= c1_tmp2;
    c1_ixLead++;
    c1_y[c1_iyLead] = c1_tmp1;
    c1_iyLead++;
  }
}

static real_T c1_sumColumnB(SFc1_flightControlSystemInstanceStruct
  *chartInstance, real_T c1_x[178])
{
  real_T c1_y;
  int32_T c1_b_k;
  int32_T c1_k;
  (void)chartInstance;
  c1_y = c1_x[0];
  for (c1_k = 0; c1_k < 177; c1_k++) {
    c1_b_k = c1_k;
    c1_y += c1_x[c1_b_k + 1];
  }

  return c1_y;
}

static real_T c1_b_sumColumnB(SFc1_flightControlSystemInstanceStruct
  *chartInstance, real_T c1_x_data[], int32_T c1_vlen)
{
  real_T c1_y;
  int32_T c1_b_vlen;
  int32_T c1_c_i1;
  int32_T c1_i;
  int32_T c1_k;
  (void)chartInstance;
  c1_b_vlen = c1_vlen - 1;
  c1_y = c1_x_data[0];
  c1_i = c1_b_vlen;
  c1_c_i1 = (uint8_T)c1_i - 1;
  for (c1_k = 0; c1_k <= c1_c_i1; c1_k++) {
    c1_y += c1_x_data[1];
  }

  return c1_y;
}

static real_T c1_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_b_DegAngle, const char_T *c1_identifier)
{
  emlrtMsgIdentifier c1_thisId;
  real_T c1_y;
  c1_thisId.fIdentifier = (const char_T *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_y = c1_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_DegAngle),
    &c1_thisId);
  sf_mex_destroy(&c1_b_DegAngle);
  return c1_y;
}

static real_T c1_b_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  real_T c1_d;
  real_T c1_y;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), &c1_d, 1, 0, 0U, 0, 0U, 0);
  c1_y = c1_d;
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static uint8_T c1_c_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_b_is_active_c1_flightControlSystem, const
  char_T *c1_identifier)
{
  emlrtMsgIdentifier c1_thisId;
  uint8_T c1_y;
  c1_thisId.fIdentifier = (const char_T *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_y = c1_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c1_b_is_active_c1_flightControlSystem), &c1_thisId);
  sf_mex_destroy(&c1_b_is_active_c1_flightControlSystem);
  return c1_y;
}

static uint8_T c1_d_emlrt_marshallIn(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  uint8_T c1_b_u;
  uint8_T c1_y;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), &c1_b_u, 1, 3, 0U, 0, 0U, 0);
  c1_y = c1_b_u;
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static void c1_slStringInitializeDynamicBuffers
  (SFc1_flightControlSystemInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_chart_data_browse_helper(SFc1_flightControlSystemInstanceStruct
  *chartInstance, int32_T c1_ssIdNumber, const mxArray **c1_mxData, uint8_T
  *c1_isValueTooBig)
{
  real_T c1_d;
  *c1_mxData = NULL;
  *c1_mxData = NULL;
  *c1_isValueTooBig = 0U;
  switch (c1_ssIdNumber) {
   case 4U:
    sf_mex_assign(c1_mxData, sf_mex_create("mxData", *chartInstance->c1_BWimage,
      0, 0U, 1U, 0U, 2, 118, 158), false);
    break;

   case 5U:
    c1_d = *chartInstance->c1_DegAngle;
    sf_mex_assign(c1_mxData, sf_mex_create("mxData", &c1_d, 0, 0U, 0U, 0U, 0),
                  false);
    break;
  }
}

static const mxArray *c1_feval(SFc1_flightControlSystemInstanceStruct
  *chartInstance, const emlrtStack *c1_sp, const mxArray *c1_input0, const
  mxArray *c1_input1)
{
  const mxArray *c1_m = NULL;
  (void)chartInstance;
  c1_m = NULL;
  sf_mex_assign(&c1_m, sf_mex_call(c1_sp, NULL, "feval", 1U, 2U, 14, sf_mex_dup
    (c1_input0), 14, sf_mex_dup(c1_input1)), false);
  sf_mex_destroy(&c1_input0);
  sf_mex_destroy(&c1_input1);
  return c1_m;
}

static void c1_b_feval(SFc1_flightControlSystemInstanceStruct *chartInstance,
  const emlrtStack *c1_sp, const mxArray *c1_input0, const mxArray *c1_input1)
{
  (void)chartInstance;
  sf_mex_call(c1_sp, NULL, "feval", 0U, 2U, 14, sf_mex_dup(c1_input0), 14,
              sf_mex_dup(c1_input1));
  sf_mex_destroy(&c1_input0);
  sf_mex_destroy(&c1_input1);
}

static void init_dsm_address_info(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc1_flightControlSystemInstanceStruct
  *chartInstance)
{
  chartInstance->c1_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c1_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c1_BWimage = (real_T (*)[18644])ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c1_DegAngle = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3042637555U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3955949436U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3399381507U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3827008097U);
}

mxArray *sf_c1_flightControlSystem_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,5);
  mxSetCell(mxcell3p, 0, mxCreateString(
             "images.internal.coder.buildable.IppfilterBuildable"));
  mxSetCell(mxcell3p, 1, mxCreateString(
             "images.internal.coder.buildable.ImfilterBuildable"));
  mxSetCell(mxcell3p, 2, mxCreateString(
             "images.internal.coder.buildable.GetnumcoresBuildable"));
  mxSetCell(mxcell3p, 3, mxCreateString(
             "images.internal.coder.buildable.CannyThresholdingTbbBuildable"));
  mxSetCell(mxcell3p, 4, mxCreateString(
             "images.internal.coder.buildable.IppreconstructBuildable"));
  return(mxcell3p);
}

mxArray *sf_c1_flightControlSystem_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("ippfilter_real64");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c1_flightControlSystem_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c1_flightControlSystem(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPhDBxMDABqQ4IEwwYIXyGaFijHBxFri4AhCXVBakgsSLi5I9U4B0XmIumJ9YWuG"
    "Zl5YPNt+CAWE+GxbzGZHM54SKQ8AHe8r0izig62fBop8DSb8AlO+Smu6Yl56TygcVp8wdCg6U6Y"
    "fYH0DAHwpo/gDxM4vjE5NLMstS45MN49NyMtMzSpzz80qK8nOCK4tLUnNh/gMAQPUeUg=="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c1_flightControlSystem_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sfK7PEjwiC2oDyKGkATJESE";
}

static void sf_opaque_initialize_c1_flightControlSystem(void *chartInstanceVar)
{
  initialize_params_c1_flightControlSystem
    ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar);
  initialize_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c1_flightControlSystem(void *chartInstanceVar)
{
  enable_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c1_flightControlSystem(void *chartInstanceVar)
{
  disable_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c1_flightControlSystem(void *chartInstanceVar)
{
  sf_gateway_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c1_flightControlSystem(SimStruct*
  S)
{
  return get_sim_state_c1_flightControlSystem
    ((SFc1_flightControlSystemInstanceStruct *)sf_get_chart_instance_ptr(S));/* raw sim ctx */
}

static void sf_opaque_set_sim_state_c1_flightControlSystem(SimStruct* S, const
  mxArray *st)
{
  set_sim_state_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_cleanup_runtime_resources_c1_flightControlSystem(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_flightControlSystem_optimization_info();
    }

    mdl_cleanup_runtime_resources_c1_flightControlSystem
      ((SFc1_flightControlSystemInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c1_flightControlSystem(void *chartInstanceVar)
{
  mdl_start_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_mdl_terminate_c1_flightControlSystem(void
  *chartInstanceVar)
{
  mdl_terminate_c1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c1_flightControlSystem(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c1_flightControlSystem
      ((SFc1_flightControlSystemInstanceStruct*)sf_get_chart_instance_ptr(S));
    initSimStructsc1_flightControlSystem((SFc1_flightControlSystemInstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c1_flightControlSystem_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [22] = {
    "eNrtWE1v40QYnlal2oWl2gNitdJK9IhASLtFCA4ImibOEralEU6LxKWa2m/sIeMZ73wkDeIf8Af",
    "2Z3DkxO/gxoUrEkeOvGM72cgNrSeBsouw5LoT+3k/Hr9fY7LROyJ47OD57D4h23i9hecmKY9Xqv",
    "XGwln+vkU+rtbfvUZIJGNIQIR2OGQXxO8QNutTRTNN/A9BM/gStOTWMCl6YiibY5kYggIRoYBcK",
    "uOlV7PMciZGXSsip1l/lbIoDVNpeXyAAml8LPj0r/Tm1vRRY4cpiEwXIDapkjZJu5wmV7OgzKSd",
    "QjTSNvPmSoMJbe5c1UeWG5ZzCC4g6gltKLKgr/E3NNRA21z4kez81eEMLbOcMyqac51SHUKO0WH",
    "gJI/x77E1yF4jbJRSZQ4gpWPQh2xUaJcCGmlnGp8+Z4IaqRjlQcbbTlpDf/scfTzClOC+7wj9PV",
    "BAR7lkwngmRNhFngNBzzl04NwmnnpDeGpdNpwymIDye7/DthyDogkcCz+bi3cUXBRBOc+lhljDM",
    "jilqhVh7GqI/eoGJp0OKYYjDFCMFxYKint6oNgYY8O31vVc+q9U62xWRr9eCVvoDcbgHVdzvd1I",
    "tCnn2g87kPkhjIEX+jvU0BWwpX4PsNYsHkiMDldtPCuWFQwzocK2pYhZ86gc11BFY/sCm1QDOMt",
    "cGkCMNM9Nnwu6Lo+sNjJrY8npHB421HcZ2xMG1JBG0LjHKMo0oMFFXHnqjZl2iYRoZMkUXjaWUO",
    "bgSlCih1Z0JlKNkGPfZvacK5cJfmiIEyzMBooiF2B0n1JuG9qc6QTzB8PjRGOV9dOLWJc/K4EjG",
    "qUQu87JOBxhnUUBTV+xdi2/hd6OmZl2QEeK5U0zyWJBx6brWBpMczgRIyEnoqtkFlaT1xVxBYBV",
    "gyrBRHKALVxNu2h8M6sVPB0U1d13yHE8U8PpuYuNxyCwGzpf3dRAI8yqQOCIjAatgw3ZtzjECM2",
    "0wUY9LVt92ffc/P4ZeT6/by2Z399cmN/vVuvo0dmQsyR1hcYoycMpys5KeQ8X5N1psB+Y2XEVjl",
    "zCkTludn17Ab+xRC9ZuNb13d682s5N/G+jwu0v4F6v6dmq4bYrzt59tvPOL79Ovj/88bf+qz+dH",
    "q2j/4dNv/3WTrV+MJub5lV6fKmQNYmHe7V4uFfUxicf9oNvJqy9JzvTJ49HrcHnQRiU7+caezdr",
    "9s5+33WzGiZxURNU1IurfZtbU1vuJ5z8jxbs3b6Gj9sL8UTI75+uh39jv45fxtetGl9u3YGkJRI",
    "Oi/G7uh27++vhS/39a/zYrfmxW8zwZ9RVajhbXhF2/oZ888WRG8a9LHb+z8s/71+TfnfTOHLDuH",
    "X98+3jL/vzD6+ou6T2/N0X2I/6ddV57kXz62fiN2+9Va0/mX9PaKeMx0t2NNVt3HQMl939j8T3H",
    "578zebLwPFXfXj++v2WoHyKW5hyi1j93Ffu++H8lgKql+8T/41+QpbsF5bNVXdq+e3WEyZiOdHv",
    "Pdr7YG+d/vQnbZgfzw==",
    ""
  };

  static char newstr [1521] = "";
  newstr[0] = '\0';
  for (i = 0; i < 22; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c1_flightControlSystem(SimStruct *S)
{
  const char* newstr = sf_c1_flightControlSystem_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(705599531U));
  ssSetChecksum1(S,(2339890399U));
  ssSetChecksum2(S,(1357756492U));
  ssSetChecksum3(S,(1297530378U));
}

static void mdlRTW_c1_flightControlSystem(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c1_flightControlSystem(SimStruct *S)
{
  SFc1_flightControlSystemInstanceStruct *chartInstance;
  chartInstance = (SFc1_flightControlSystemInstanceStruct *)utMalloc(sizeof
    (SFc1_flightControlSystemInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc1_flightControlSystemInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c1_flightControlSystem;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c1_flightControlSystem;
  chartInstance->chartInfo.mdlStart = sf_opaque_mdl_start_c1_flightControlSystem;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c1_flightControlSystem;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c1_flightControlSystem;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c1_flightControlSystem;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c1_flightControlSystem;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c1_flightControlSystem;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c1_flightControlSystem;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c1_flightControlSystem;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c1_flightControlSystem;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c1_flightControlSystem;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->chartInfo.chartStateSetterFcn = NULL;
  chartInstance->chartInfo.chartStateGetterFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c1_JITStateAnimation,
    chartInstance->c1_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c1_flightControlSystem(chartInstance);
}

void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c1_flightControlSystem(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c1_flightControlSystem(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c1_flightControlSystem(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c1_flightControlSystem_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
