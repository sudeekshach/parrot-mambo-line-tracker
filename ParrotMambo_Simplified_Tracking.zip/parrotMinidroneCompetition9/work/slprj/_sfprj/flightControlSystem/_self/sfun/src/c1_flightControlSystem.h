#ifndef __c1_flightControlSystem_h__
#define __c1_flightControlSystem_h__

/* Forward Declarations */
#ifndef typedef_c1_szuUIsjSIN6GWJW5YzVNVmG
#define typedef_c1_szuUIsjSIN6GWJW5YzVNVmG

typedef struct c1_tag_szuUIsjSIN6GWJW5YzVNVmG c1_szuUIsjSIN6GWJW5YzVNVmG;

#endif                                 /* typedef_c1_szuUIsjSIN6GWJW5YzVNVmG */

#ifndef typedef_c1_s9s8BC13iTohZXRbLMSIDHE
#define typedef_c1_s9s8BC13iTohZXRbLMSIDHE

typedef struct c1_tag_s9s8BC13iTohZXRbLMSIDHE c1_s9s8BC13iTohZXRbLMSIDHE;

#endif                                 /* typedef_c1_s9s8BC13iTohZXRbLMSIDHE */

#ifndef typedef_c1_skZBV47kFp42DPFCMXy0uBE
#define typedef_c1_skZBV47kFp42DPFCMXy0uBE

typedef struct c1_tag_skZBV47kFp42DPFCMXy0uBE c1_skZBV47kFp42DPFCMXy0uBE;

#endif                                 /* typedef_c1_skZBV47kFp42DPFCMXy0uBE */

#ifndef typedef_c1_s_0K68mFBjQDo1WRxKPpRFgD
#define typedef_c1_s_0K68mFBjQDo1WRxKPpRFgD

typedef struct c1_tag_0K68mFBjQDo1WRxKPpRFgD c1_s_0K68mFBjQDo1WRxKPpRFgD;

#endif                                 /* typedef_c1_s_0K68mFBjQDo1WRxKPpRFgD */

#ifndef typedef_c1_s_P9BqU0OiPAu5sFhUNvbXPC
#define typedef_c1_s_P9BqU0OiPAu5sFhUNvbXPC

typedef struct c1_tag_P9BqU0OiPAu5sFhUNvbXPC c1_s_P9BqU0OiPAu5sFhUNvbXPC;

#endif                                 /* typedef_c1_s_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG
#define typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c1_tag_a7TcNrdk5JZcy5uxGijaRG c1_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef typedef_c1_cell_1
#define typedef_c1_cell_1

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_1;

#endif                                 /* typedef_c1_cell_1 */

#ifndef typedef_c1_cell_2
#define typedef_c1_cell_2

typedef struct c1_tag_TM19LyJsa5LnbAbn5kdkNF c1_cell_2;

#endif                                 /* typedef_c1_cell_2 */

#ifndef typedef_c1_cell_3
#define typedef_c1_cell_3

typedef struct c1_tag_7Te4OFDdKI7zKK1PSL4sfF c1_cell_3;

#endif                                 /* typedef_c1_cell_3 */

#ifndef typedef_c1_cell_wrap_4
#define typedef_c1_cell_wrap_4

typedef struct c1_tag_arNsAu0k4EKn3oJmOQ4PR c1_cell_wrap_4;

#endif                                 /* typedef_c1_cell_wrap_4 */

#ifndef typedef_c1_cell_5
#define typedef_c1_cell_5

typedef struct c1_tag_4f3zucywOvoC0QgnMj36nF c1_cell_5;

#endif                                 /* typedef_c1_cell_5 */

#ifndef typedef_c1_cell_wrap_6
#define typedef_c1_cell_wrap_6

typedef struct c1_tag_y2anywF90yUI9j7qH5yd3E c1_cell_wrap_6;

#endif                                 /* typedef_c1_cell_wrap_6 */

#ifndef typedef_c1_cell_wrap_7
#define typedef_c1_cell_wrap_7

typedef struct c1_tag_ge1UD3YqHcNerzgtJ4AjXF c1_cell_wrap_7;

#endif                                 /* typedef_c1_cell_wrap_7 */

#ifndef typedef_c1_cell_8
#define typedef_c1_cell_8

typedef struct c1_tag_EX2wxrf7UhZ6FVbfRZyo7B c1_cell_8;

#endif                                 /* typedef_c1_cell_8 */

#ifndef typedef_c1_cell_9
#define typedef_c1_cell_9

typedef struct c1_tag_wvqtwQNAx0JJ5IpvMHRcsG c1_cell_9;

#endif                                 /* typedef_c1_cell_9 */

#ifndef typedef_c1_cell_10
#define typedef_c1_cell_10

typedef struct c1_tag_awFMsYYWj01uO3vmLPQJOE c1_cell_10;

#endif                                 /* typedef_c1_cell_10 */

#ifndef typedef_c1_cell_11
#define typedef_c1_cell_11

typedef struct c1_tag_WYClaNMLzsYbJFiV2mng6F c1_cell_11;

#endif                                 /* typedef_c1_cell_11 */

#ifndef typedef_c1_cell_wrap_0
#define typedef_c1_cell_wrap_0

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_0;

#endif                                 /* typedef_c1_cell_wrap_0 */

#ifndef typedef_c1_cell_12
#define typedef_c1_cell_12

typedef struct c1_tag_BoX4lGjW7CLGNTo2OWmlp c1_cell_12;

#endif                                 /* typedef_c1_cell_12 */

#ifndef typedef_c1_cell_13
#define typedef_c1_cell_13

typedef struct c1_tag_6CsBRVljdCQyAxGT7eZM3E c1_cell_13;

#endif                                 /* typedef_c1_cell_13 */

#ifndef typedef_c1_cell_15
#define typedef_c1_cell_15

typedef struct c1_tag_URxaCoPZWr69Oy7fwnFxl c1_cell_15;

#endif                                 /* typedef_c1_cell_15 */

#ifndef typedef_c1_cell_16
#define typedef_c1_cell_16

typedef struct c1_tag_yMfj6323Zqv19VFnWGoHjH c1_cell_16;

#endif                                 /* typedef_c1_cell_16 */

#ifndef typedef_c1_cell_17
#define typedef_c1_cell_17

typedef struct c1_tag_kS8ceVSqQXZwOLTLRGuZQC c1_cell_17;

#endif                                 /* typedef_c1_cell_17 */

#ifndef typedef_c1_cell_18
#define typedef_c1_cell_18

typedef struct c1_tag_Se3bDHKMt28bXt374He6IB c1_cell_18;

#endif                                 /* typedef_c1_cell_18 */

#ifndef typedef_c1_cell_19
#define typedef_c1_cell_19

typedef struct c1_tag_4uvGTEjvHQUqIbuB33mmHB c1_cell_19;

#endif                                 /* typedef_c1_cell_19 */

#ifndef typedef_c1_cell_20
#define typedef_c1_cell_20

typedef struct c1_tag_cUWaYEfJVKrwLRux1qG4UF c1_cell_20;

#endif                                 /* typedef_c1_cell_20 */

#ifndef typedef_c1_cell_21
#define typedef_c1_cell_21

typedef struct c1_tag_oanHHIkf1jJJFv0zKMaqxG c1_cell_21;

#endif                                 /* typedef_c1_cell_21 */

#ifndef typedef_c1_cell_22
#define typedef_c1_cell_22

typedef struct c1_tag_tOVohXlnRgOVmYnwYHCFcH c1_cell_22;

#endif                                 /* typedef_c1_cell_22 */

#ifndef typedef_c1_cell_23
#define typedef_c1_cell_23

typedef struct c1_tag_QxFbldG57tOstWLr33LOmB c1_cell_23;

#endif                                 /* typedef_c1_cell_23 */

#ifndef typedef_c1_cell_24
#define typedef_c1_cell_24

typedef struct c1_tag_DwCj7Xnd6JZ0A1dXnN5rc c1_cell_24;

#endif                                 /* typedef_c1_cell_24 */

#ifndef typedef_c1_cell_25
#define typedef_c1_cell_25

typedef struct c1_tag_gXbtcthfT36yc3y9NSOpHB c1_cell_25;

#endif                                 /* typedef_c1_cell_25 */

#ifndef typedef_c1_cell_26
#define typedef_c1_cell_26

typedef struct c1_tag_sQqzhT6lgzOQlKB8EVZ4HF c1_cell_26;

#endif                                 /* typedef_c1_cell_26 */

#ifndef typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD
#define typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c1_tag_tP4ysjhyvuYk36JuHDg8bD c1_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef typedef_c1_s_y30bjXPnZrp2waraWnJSvH
#define typedef_c1_s_y30bjXPnZrp2waraWnJSvH

typedef struct c1_tag_y30bjXPnZrp2waraWnJSvH c1_s_y30bjXPnZrp2waraWnJSvH;

#endif                                 /* typedef_c1_s_y30bjXPnZrp2waraWnJSvH */

#ifndef typedef_c1_s_hq4Z13O5hXdQ9UsncvBGlF
#define typedef_c1_s_hq4Z13O5hXdQ9UsncvBGlF

typedef struct c1_tag_hq4Z13O5hXdQ9UsncvBGlF c1_s_hq4Z13O5hXdQ9UsncvBGlF;

#endif                                 /* typedef_c1_s_hq4Z13O5hXdQ9UsncvBGlF */

#ifndef typedef_c1_s_GZjSpaey3IDRqvh7nZoQMD
#define typedef_c1_s_GZjSpaey3IDRqvh7nZoQMD

typedef struct c1_tag_GZjSpaey3IDRqvh7nZoQMD c1_s_GZjSpaey3IDRqvh7nZoQMD;

#endif                                 /* typedef_c1_s_GZjSpaey3IDRqvh7nZoQMD */

#ifndef typedef_c1_s_zhWislg2JXfOJCG0FlayVG
#define typedef_c1_s_zhWislg2JXfOJCG0FlayVG

typedef struct c1_tag_zhWislg2JXfOJCG0FlayVG c1_s_zhWislg2JXfOJCG0FlayVG;

#endif                                 /* typedef_c1_s_zhWislg2JXfOJCG0FlayVG */

#ifndef typedef_c1_s_BrRdqYMft44ulwR1A7rKqF
#define typedef_c1_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c1_tag_BrRdqYMft44ulwR1A7rKqF c1_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* typedef_c1_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef typedef_c1_s_lnEOVMt12CNg5nSw1iwvNF
#define typedef_c1_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct c1_tag_lnEOVMt12CNg5nSw1iwvNF c1_s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* typedef_c1_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef typedef_c1_s_Uq8YUzQmSy3K1TONPeIAhC
#define typedef_c1_s_Uq8YUzQmSy3K1TONPeIAhC

typedef struct c1_tag_Uq8YUzQmSy3K1TONPeIAhC c1_s_Uq8YUzQmSy3K1TONPeIAhC;

#endif                                 /* typedef_c1_s_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef typedef_c1_s_i8jNnI3x8wo4JAox5HV9WF
#define typedef_c1_s_i8jNnI3x8wo4JAox5HV9WF

typedef struct c1_tag_i8jNnI3x8wo4JAox5HV9WF c1_s_i8jNnI3x8wo4JAox5HV9WF;

#endif                                 /* typedef_c1_s_i8jNnI3x8wo4JAox5HV9WF */

#ifndef typedef_c1_s_dV11HShs2d9BqwRJb6HgvD
#define typedef_c1_s_dV11HShs2d9BqwRJb6HgvD

typedef struct c1_tag_dV11HShs2d9BqwRJb6HgvD c1_s_dV11HShs2d9BqwRJb6HgvD;

#endif                                 /* typedef_c1_s_dV11HShs2d9BqwRJb6HgvD */

#ifndef typedef_c1_s_HSHOljOSgF7qDZeWd2IfH
#define typedef_c1_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c1_tag_HSHOljOSgF7qDZeWd2IfH c1_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* typedef_c1_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_c1_s_23YJI910RYCWhAsXw5RjrG
#define typedef_c1_s_23YJI910RYCWhAsXw5RjrG

typedef struct c1_tag_23YJI910RYCWhAsXw5RjrG c1_s_23YJI910RYCWhAsXw5RjrG;

#endif                                 /* typedef_c1_s_23YJI910RYCWhAsXw5RjrG */

#ifndef typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH
#define typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH c1_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef typedef_c1_s_u4ui3JwwaZ1jYzDQeNl7gB
#define typedef_c1_s_u4ui3JwwaZ1jYzDQeNl7gB

typedef struct c1_tag_u4ui3JwwaZ1jYzDQeNl7gB c1_s_u4ui3JwwaZ1jYzDQeNl7gB;

#endif                                 /* typedef_c1_s_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef typedef_c1_s_lv60kHidgCVN68cHDjBCkF
#define typedef_c1_s_lv60kHidgCVN68cHDjBCkF

typedef struct c1_tag_lv60kHidgCVN68cHDjBCkF c1_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* typedef_c1_s_lv60kHidgCVN68cHDjBCkF */

#ifndef typedef_c1_s_MQfHiYk2RSY7P6gdFv6fDB
#define typedef_c1_s_MQfHiYk2RSY7P6gdFv6fDB

typedef struct c1_tag_MQfHiYk2RSY7P6gdFv6fDB c1_s_MQfHiYk2RSY7P6gdFv6fDB;

#endif                                 /* typedef_c1_s_MQfHiYk2RSY7P6gdFv6fDB */

#ifndef typedef_c1_s_zyomqXisN60TlgNyBJHFGG
#define typedef_c1_s_zyomqXisN60TlgNyBJHFGG

typedef struct c1_tag_zyomqXisN60TlgNyBJHFGG c1_s_zyomqXisN60TlgNyBJHFGG;

#endif                                 /* typedef_c1_s_zyomqXisN60TlgNyBJHFGG */

#ifndef typedef_c1_s_7xbvANdg7KAufDVBBSkgZE
#define typedef_c1_s_7xbvANdg7KAufDVBBSkgZE

typedef struct c1_tag_7xbvANdg7KAufDVBBSkgZE c1_s_7xbvANdg7KAufDVBBSkgZE;

#endif                                 /* typedef_c1_s_7xbvANdg7KAufDVBBSkgZE */

#ifndef typedef_c1_s_FT1dThmKyyOBY5mTNhhCiC
#define typedef_c1_s_FT1dThmKyyOBY5mTNhhCiC

typedef struct c1_tag_FT1dThmKyyOBY5mTNhhCiC c1_s_FT1dThmKyyOBY5mTNhhCiC;

#endif                                 /* typedef_c1_s_FT1dThmKyyOBY5mTNhhCiC */

#ifndef typedef_c1_s_LiC67LW1mMO192u9sMnmMG
#define typedef_c1_s_LiC67LW1mMO192u9sMnmMG

typedef struct c1_tag_LiC67LW1mMO192u9sMnmMG c1_s_LiC67LW1mMO192u9sMnmMG;

#endif                                 /* typedef_c1_s_LiC67LW1mMO192u9sMnmMG */

#ifndef typedef_c1_s_MNdGPE827fhwyzcwIbJ2SF
#define typedef_c1_s_MNdGPE827fhwyzcwIbJ2SF

typedef struct c1_tag_MNdGPE827fhwyzcwIbJ2SF c1_s_MNdGPE827fhwyzcwIbJ2SF;

#endif                                 /* typedef_c1_s_MNdGPE827fhwyzcwIbJ2SF */

#ifndef typedef_c1_s_GvWTNEJOSSRh883m2SnETB
#define typedef_c1_s_GvWTNEJOSSRh883m2SnETB

typedef struct c1_tag_GvWTNEJOSSRh883m2SnETB c1_s_GvWTNEJOSSRh883m2SnETB;

#endif                                 /* typedef_c1_s_GvWTNEJOSSRh883m2SnETB */

#ifndef typedef_c1_s_Z2qSppxNoXb8Jppd82oq6F
#define typedef_c1_s_Z2qSppxNoXb8Jppd82oq6F

typedef struct c1_tag_Z2qSppxNoXb8Jppd82oq6F c1_s_Z2qSppxNoXb8Jppd82oq6F;

#endif                                 /* typedef_c1_s_Z2qSppxNoXb8Jppd82oq6F */

#ifndef typedef_c1_s_bfdw51ZQJqFWZgII8x0zkH
#define typedef_c1_s_bfdw51ZQJqFWZgII8x0zkH

typedef struct c1_tag_bfdw51ZQJqFWZgII8x0zkH c1_s_bfdw51ZQJqFWZgII8x0zkH;

#endif                                 /* typedef_c1_s_bfdw51ZQJqFWZgII8x0zkH */

#ifndef typedef_c1_s_Zk8dErMjLMrsJtNaWjimqH
#define typedef_c1_s_Zk8dErMjLMrsJtNaWjimqH

typedef struct c1_tag_Zk8dErMjLMrsJtNaWjimqH c1_s_Zk8dErMjLMrsJtNaWjimqH;

#endif                                 /* typedef_c1_s_Zk8dErMjLMrsJtNaWjimqH */

/* Type Definitions */
#ifndef struct_c1_tag_szuUIsjSIN6GWJW5YzVNVmG
#define struct_c1_tag_szuUIsjSIN6GWJW5YzVNVmG

struct c1_tag_szuUIsjSIN6GWJW5YzVNVmG
{
  uint32_T Theta;
  uint32_T RhoResolution;
};

#endif                                 /* struct_c1_tag_szuUIsjSIN6GWJW5YzVNVmG */

#ifndef typedef_c1_szuUIsjSIN6GWJW5YzVNVmG
#define typedef_c1_szuUIsjSIN6GWJW5YzVNVmG

typedef struct c1_tag_szuUIsjSIN6GWJW5YzVNVmG c1_szuUIsjSIN6GWJW5YzVNVmG;

#endif                                 /* typedef_c1_szuUIsjSIN6GWJW5YzVNVmG */

#ifndef struct_c1_tag_s9s8BC13iTohZXRbLMSIDHE
#define struct_c1_tag_s9s8BC13iTohZXRbLMSIDHE

struct c1_tag_s9s8BC13iTohZXRbLMSIDHE
{
  boolean_T CaseSensitivity;
  boolean_T StructExpand;
  boolean_T PartialMatching;
};

#endif                                 /* struct_c1_tag_s9s8BC13iTohZXRbLMSIDHE */

#ifndef typedef_c1_s9s8BC13iTohZXRbLMSIDHE
#define typedef_c1_s9s8BC13iTohZXRbLMSIDHE

typedef struct c1_tag_s9s8BC13iTohZXRbLMSIDHE c1_s9s8BC13iTohZXRbLMSIDHE;

#endif                                 /* typedef_c1_s9s8BC13iTohZXRbLMSIDHE */

#ifndef struct_c1_tag_skZBV47kFp42DPFCMXy0uBE
#define struct_c1_tag_skZBV47kFp42DPFCMXy0uBE

struct c1_tag_skZBV47kFp42DPFCMXy0uBE
{
  uint32_T Threshold;
  uint32_T NHoodSize;
  uint32_T Theta;
};

#endif                                 /* struct_c1_tag_skZBV47kFp42DPFCMXy0uBE */

#ifndef typedef_c1_skZBV47kFp42DPFCMXy0uBE
#define typedef_c1_skZBV47kFp42DPFCMXy0uBE

typedef struct c1_tag_skZBV47kFp42DPFCMXy0uBE c1_skZBV47kFp42DPFCMXy0uBE;

#endif                                 /* typedef_c1_skZBV47kFp42DPFCMXy0uBE */

#ifndef struct_c1_tag_0K68mFBjQDo1WRxKPpRFgD
#define struct_c1_tag_0K68mFBjQDo1WRxKPpRFgD

struct c1_tag_0K68mFBjQDo1WRxKPpRFgD
{
  int32_T f1;
  int32_T f2;
};

#endif                                 /* struct_c1_tag_0K68mFBjQDo1WRxKPpRFgD */

#ifndef typedef_c1_s_0K68mFBjQDo1WRxKPpRFgD
#define typedef_c1_s_0K68mFBjQDo1WRxKPpRFgD

typedef struct c1_tag_0K68mFBjQDo1WRxKPpRFgD c1_s_0K68mFBjQDo1WRxKPpRFgD;

#endif                                 /* typedef_c1_s_0K68mFBjQDo1WRxKPpRFgD */

#ifndef struct_c1_tag_P9BqU0OiPAu5sFhUNvbXPC
#define struct_c1_tag_P9BqU0OiPAu5sFhUNvbXPC

struct c1_tag_P9BqU0OiPAu5sFhUNvbXPC
{
  c1_s_0K68mFBjQDo1WRxKPpRFgD _data;
};

#endif                                 /* struct_c1_tag_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef typedef_c1_s_P9BqU0OiPAu5sFhUNvbXPC
#define typedef_c1_s_P9BqU0OiPAu5sFhUNvbXPC

typedef struct c1_tag_P9BqU0OiPAu5sFhUNvbXPC c1_s_P9BqU0OiPAu5sFhUNvbXPC;

#endif                                 /* typedef_c1_s_P9BqU0OiPAu5sFhUNvbXPC */

#ifndef struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG
#define struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG

struct c1_tag_a7TcNrdk5JZcy5uxGijaRG
{
  char_T f1[7];
  char_T f2[7];
};

#endif                                 /* struct_c1_tag_a7TcNrdk5JZcy5uxGijaRG */

#ifndef typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG
#define typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG

typedef struct c1_tag_a7TcNrdk5JZcy5uxGijaRG c1_s_a7TcNrdk5JZcy5uxGijaRG;

#endif                                 /* typedef_c1_s_a7TcNrdk5JZcy5uxGijaRG */

#ifndef struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
#define struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE

struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[2];
};

#endif                                 /* struct_c1_tag_hIvE0H0Ni3BhTo6qVK2nUE */

#ifndef typedef_c1_cell_1
#define typedef_c1_cell_1

typedef struct c1_tag_hIvE0H0Ni3BhTo6qVK2nUE c1_cell_1;

#endif                                 /* typedef_c1_cell_1 */

#ifndef struct_c1_tag_TM19LyJsa5LnbAbn5kdkNF
#define struct_c1_tag_TM19LyJsa5LnbAbn5kdkNF

struct c1_tag_TM19LyJsa5LnbAbn5kdkNF
{
  char_T f1[5];
  char_T f2[5];
  char_T f3[7];
  char_T f4[7];
  char_T f5[3];
  char_T f6[9];
};

#endif                                 /* struct_c1_tag_TM19LyJsa5LnbAbn5kdkNF */

#ifndef typedef_c1_cell_2
#define typedef_c1_cell_2

typedef struct c1_tag_TM19LyJsa5LnbAbn5kdkNF c1_cell_2;

#endif                                 /* typedef_c1_cell_2 */

#ifndef struct_c1_tag_7Te4OFDdKI7zKK1PSL4sfF
#define struct_c1_tag_7Te4OFDdKI7zKK1PSL4sfF

struct c1_tag_7Te4OFDdKI7zKK1PSL4sfF
{
  char_T f1[5];
  char_T f2[7];
  char_T f3[7];
};

#endif                                 /* struct_c1_tag_7Te4OFDdKI7zKK1PSL4sfF */

#ifndef typedef_c1_cell_3
#define typedef_c1_cell_3

typedef struct c1_tag_7Te4OFDdKI7zKK1PSL4sfF c1_cell_3;

#endif                                 /* typedef_c1_cell_3 */

#ifndef struct_c1_tag_arNsAu0k4EKn3oJmOQ4PR
#define struct_c1_tag_arNsAu0k4EKn3oJmOQ4PR

struct c1_tag_arNsAu0k4EKn3oJmOQ4PR
{
  char_T f1[5];
};

#endif                                 /* struct_c1_tag_arNsAu0k4EKn3oJmOQ4PR */

#ifndef typedef_c1_cell_wrap_4
#define typedef_c1_cell_wrap_4

typedef struct c1_tag_arNsAu0k4EKn3oJmOQ4PR c1_cell_wrap_4;

#endif                                 /* typedef_c1_cell_wrap_4 */

#ifndef struct_c1_tag_4f3zucywOvoC0QgnMj36nF
#define struct_c1_tag_4f3zucywOvoC0QgnMj36nF

struct c1_tag_4f3zucywOvoC0QgnMj36nF
{
  char_T f1[4];
  char_T f2[5];
  char_T f3[5];
  char_T f4[6];
  char_T f5[5];
  char_T f6[6];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* struct_c1_tag_4f3zucywOvoC0QgnMj36nF */

#ifndef typedef_c1_cell_5
#define typedef_c1_cell_5

typedef struct c1_tag_4f3zucywOvoC0QgnMj36nF c1_cell_5;

#endif                                 /* typedef_c1_cell_5 */

#ifndef struct_c1_tag_y2anywF90yUI9j7qH5yd3E
#define struct_c1_tag_y2anywF90yUI9j7qH5yd3E

struct c1_tag_y2anywF90yUI9j7qH5yd3E
{
  char_T f1[9];
};

#endif                                 /* struct_c1_tag_y2anywF90yUI9j7qH5yd3E */

#ifndef typedef_c1_cell_wrap_6
#define typedef_c1_cell_wrap_6

typedef struct c1_tag_y2anywF90yUI9j7qH5yd3E c1_cell_wrap_6;

#endif                                 /* typedef_c1_cell_wrap_6 */

#ifndef struct_c1_tag_ge1UD3YqHcNerzgtJ4AjXF
#define struct_c1_tag_ge1UD3YqHcNerzgtJ4AjXF

struct c1_tag_ge1UD3YqHcNerzgtJ4AjXF
{
  char_T f1[6];
};

#endif                                 /* struct_c1_tag_ge1UD3YqHcNerzgtJ4AjXF */

#ifndef typedef_c1_cell_wrap_7
#define typedef_c1_cell_wrap_7

typedef struct c1_tag_ge1UD3YqHcNerzgtJ4AjXF c1_cell_wrap_7;

#endif                                 /* typedef_c1_cell_wrap_7 */

#ifndef struct_c1_tag_EX2wxrf7UhZ6FVbfRZyo7B
#define struct_c1_tag_EX2wxrf7UhZ6FVbfRZyo7B

struct c1_tag_EX2wxrf7UhZ6FVbfRZyo7B
{
  char_T f1[9];
  char_T f2[9];
  char_T f3[8];
  char_T f4[4];
  char_T f5[4];
  char_T f6[4];
  char_T f7[4];
};

#endif                                 /* struct_c1_tag_EX2wxrf7UhZ6FVbfRZyo7B */

#ifndef typedef_c1_cell_8
#define typedef_c1_cell_8

typedef struct c1_tag_EX2wxrf7UhZ6FVbfRZyo7B c1_cell_8;

#endif                                 /* typedef_c1_cell_8 */

#ifndef struct_c1_tag_wvqtwQNAx0JJ5IpvMHRcsG
#define struct_c1_tag_wvqtwQNAx0JJ5IpvMHRcsG

struct c1_tag_wvqtwQNAx0JJ5IpvMHRcsG
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[11];
  char_T f5[7];
};

#endif                                 /* struct_c1_tag_wvqtwQNAx0JJ5IpvMHRcsG */

#ifndef typedef_c1_cell_9
#define typedef_c1_cell_9

typedef struct c1_tag_wvqtwQNAx0JJ5IpvMHRcsG c1_cell_9;

#endif                                 /* typedef_c1_cell_9 */

#ifndef struct_c1_tag_awFMsYYWj01uO3vmLPQJOE
#define struct_c1_tag_awFMsYYWj01uO3vmLPQJOE

struct c1_tag_awFMsYYWj01uO3vmLPQJOE
{
  char_T f1[8];
  char_T f2[9];
  char_T f3[9];
  char_T f4[3];
  char_T f5[4];
  char_T f6[4];
};

#endif                                 /* struct_c1_tag_awFMsYYWj01uO3vmLPQJOE */

#ifndef typedef_c1_cell_10
#define typedef_c1_cell_10

typedef struct c1_tag_awFMsYYWj01uO3vmLPQJOE c1_cell_10;

#endif                                 /* typedef_c1_cell_10 */

#ifndef struct_c1_tag_WYClaNMLzsYbJFiV2mng6F
#define struct_c1_tag_WYClaNMLzsYbJFiV2mng6F

struct c1_tag_WYClaNMLzsYbJFiV2mng6F
{
  char_T f1[6];
  char_T f2[5];
  char_T f3[4];
  char_T f4[7];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[5];
};

#endif                                 /* struct_c1_tag_WYClaNMLzsYbJFiV2mng6F */

#ifndef typedef_c1_cell_11
#define typedef_c1_cell_11

typedef struct c1_tag_WYClaNMLzsYbJFiV2mng6F c1_cell_11;

#endif                                 /* typedef_c1_cell_11 */

#ifndef struct_c1_tag_L5JvjW1A13FyCQi5N783sB
#define struct_c1_tag_L5JvjW1A13FyCQi5N783sB

struct c1_tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* struct_c1_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef typedef_c1_cell_wrap_0
#define typedef_c1_cell_wrap_0

typedef struct c1_tag_L5JvjW1A13FyCQi5N783sB c1_cell_wrap_0;

#endif                                 /* typedef_c1_cell_wrap_0 */

#ifndef struct_c1_tag_BoX4lGjW7CLGNTo2OWmlp
#define struct_c1_tag_BoX4lGjW7CLGNTo2OWmlp

struct c1_tag_BoX4lGjW7CLGNTo2OWmlp
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[7];
};

#endif                                 /* struct_c1_tag_BoX4lGjW7CLGNTo2OWmlp */

#ifndef typedef_c1_cell_12
#define typedef_c1_cell_12

typedef struct c1_tag_BoX4lGjW7CLGNTo2OWmlp c1_cell_12;

#endif                                 /* typedef_c1_cell_12 */

#ifndef struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E
#define struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E

struct c1_tag_6CsBRVljdCQyAxGT7eZM3E
{
  char_T f1[7];
  char_T f2[7];
  char_T f3[5];
  char_T f4[6];
  char_T f5[7];
  char_T f6[8];
};

#endif                                 /* struct_c1_tag_6CsBRVljdCQyAxGT7eZM3E */

#ifndef typedef_c1_cell_13
#define typedef_c1_cell_13

typedef struct c1_tag_6CsBRVljdCQyAxGT7eZM3E c1_cell_13;

#endif                                 /* typedef_c1_cell_13 */

#ifndef struct_c1_tag_URxaCoPZWr69Oy7fwnFxl
#define struct_c1_tag_URxaCoPZWr69Oy7fwnFxl

struct c1_tag_URxaCoPZWr69Oy7fwnFxl
{
  char_T f1[5];
  char_T f2[4];
  char_T f3[6];
  char_T f4[5];
  char_T f5[6];
  char_T f6[5];
  char_T f7[6];
  char_T f8[6];
  char_T f9[7];
};

#endif                                 /* struct_c1_tag_URxaCoPZWr69Oy7fwnFxl */

#ifndef typedef_c1_cell_15
#define typedef_c1_cell_15

typedef struct c1_tag_URxaCoPZWr69Oy7fwnFxl c1_cell_15;

#endif                                 /* typedef_c1_cell_15 */

#ifndef struct_c1_tag_yMfj6323Zqv19VFnWGoHjH
#define struct_c1_tag_yMfj6323Zqv19VFnWGoHjH

struct c1_tag_yMfj6323Zqv19VFnWGoHjH
{
  char_T f1[4];
  char_T f2[9];
  char_T f3[6];
};

#endif                                 /* struct_c1_tag_yMfj6323Zqv19VFnWGoHjH */

#ifndef typedef_c1_cell_16
#define typedef_c1_cell_16

typedef struct c1_tag_yMfj6323Zqv19VFnWGoHjH c1_cell_16;

#endif                                 /* typedef_c1_cell_16 */

#ifndef struct_c1_tag_kS8ceVSqQXZwOLTLRGuZQC
#define struct_c1_tag_kS8ceVSqQXZwOLTLRGuZQC

struct c1_tag_kS8ceVSqQXZwOLTLRGuZQC
{
  char_T f1[4];
  char_T f2[2];
  char_T f3[9];
  char_T f4[8];
};

#endif                                 /* struct_c1_tag_kS8ceVSqQXZwOLTLRGuZQC */

#ifndef typedef_c1_cell_17
#define typedef_c1_cell_17

typedef struct c1_tag_kS8ceVSqQXZwOLTLRGuZQC c1_cell_17;

#endif                                 /* typedef_c1_cell_17 */

#ifndef struct_c1_tag_Se3bDHKMt28bXt374He6IB
#define struct_c1_tag_Se3bDHKMt28bXt374He6IB

struct c1_tag_Se3bDHKMt28bXt374He6IB
{
  char_T f1[5];
  char_T f2[13];
};

#endif                                 /* struct_c1_tag_Se3bDHKMt28bXt374He6IB */

#ifndef typedef_c1_cell_18
#define typedef_c1_cell_18

typedef struct c1_tag_Se3bDHKMt28bXt374He6IB c1_cell_18;

#endif                                 /* typedef_c1_cell_18 */

#ifndef struct_c1_tag_4uvGTEjvHQUqIbuB33mmHB
#define struct_c1_tag_4uvGTEjvHQUqIbuB33mmHB

struct c1_tag_4uvGTEjvHQUqIbuB33mmHB
{
  char_T f1[15];
  char_T f2[12];
  char_T f3[15];
};

#endif                                 /* struct_c1_tag_4uvGTEjvHQUqIbuB33mmHB */

#ifndef typedef_c1_cell_19
#define typedef_c1_cell_19

typedef struct c1_tag_4uvGTEjvHQUqIbuB33mmHB c1_cell_19;

#endif                                 /* typedef_c1_cell_19 */

#ifndef struct_c1_tag_cUWaYEfJVKrwLRux1qG4UF
#define struct_c1_tag_cUWaYEfJVKrwLRux1qG4UF

struct c1_tag_cUWaYEfJVKrwLRux1qG4UF
{
  char_T f1[8];
  char_T f2[4];
  char_T f3[6];
  char_T f4[6];
};

#endif                                 /* struct_c1_tag_cUWaYEfJVKrwLRux1qG4UF */

#ifndef typedef_c1_cell_20
#define typedef_c1_cell_20

typedef struct c1_tag_cUWaYEfJVKrwLRux1qG4UF c1_cell_20;

#endif                                 /* typedef_c1_cell_20 */

#ifndef struct_c1_tag_oanHHIkf1jJJFv0zKMaqxG
#define struct_c1_tag_oanHHIkf1jJJFv0zKMaqxG

struct c1_tag_oanHHIkf1jJJFv0zKMaqxG
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[8];
};

#endif                                 /* struct_c1_tag_oanHHIkf1jJJFv0zKMaqxG */

#ifndef typedef_c1_cell_21
#define typedef_c1_cell_21

typedef struct c1_tag_oanHHIkf1jJJFv0zKMaqxG c1_cell_21;

#endif                                 /* typedef_c1_cell_21 */

#ifndef struct_c1_tag_tOVohXlnRgOVmYnwYHCFcH
#define struct_c1_tag_tOVohXlnRgOVmYnwYHCFcH

struct c1_tag_tOVohXlnRgOVmYnwYHCFcH
{
  char_T f1[4];
  char_T f2[2];
  char_T f3[9];
  char_T f4[8];
  char_T f5[6];
  char_T f6[7];
};

#endif                                 /* struct_c1_tag_tOVohXlnRgOVmYnwYHCFcH */

#ifndef typedef_c1_cell_22
#define typedef_c1_cell_22

typedef struct c1_tag_tOVohXlnRgOVmYnwYHCFcH c1_cell_22;

#endif                                 /* typedef_c1_cell_22 */

#ifndef struct_c1_tag_QxFbldG57tOstWLr33LOmB
#define struct_c1_tag_QxFbldG57tOstWLr33LOmB

struct c1_tag_QxFbldG57tOstWLr33LOmB
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[7];
  char_T f4[8];
  char_T f5[8];
};

#endif                                 /* struct_c1_tag_QxFbldG57tOstWLr33LOmB */

#ifndef typedef_c1_cell_23
#define typedef_c1_cell_23

typedef struct c1_tag_QxFbldG57tOstWLr33LOmB c1_cell_23;

#endif                                 /* typedef_c1_cell_23 */

#ifndef struct_c1_tag_DwCj7Xnd6JZ0A1dXnN5rc
#define struct_c1_tag_DwCj7Xnd6JZ0A1dXnN5rc

struct c1_tag_DwCj7Xnd6JZ0A1dXnN5rc
{
  char_T f1[9];
  char_T f2[9];
  char_T f3[5];
};

#endif                                 /* struct_c1_tag_DwCj7Xnd6JZ0A1dXnN5rc */

#ifndef typedef_c1_cell_24
#define typedef_c1_cell_24

typedef struct c1_tag_DwCj7Xnd6JZ0A1dXnN5rc c1_cell_24;

#endif                                 /* typedef_c1_cell_24 */

#ifndef struct_c1_tag_gXbtcthfT36yc3y9NSOpHB
#define struct_c1_tag_gXbtcthfT36yc3y9NSOpHB

struct c1_tag_gXbtcthfT36yc3y9NSOpHB
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[11];
};

#endif                                 /* struct_c1_tag_gXbtcthfT36yc3y9NSOpHB */

#ifndef typedef_c1_cell_25
#define typedef_c1_cell_25

typedef struct c1_tag_gXbtcthfT36yc3y9NSOpHB c1_cell_25;

#endif                                 /* typedef_c1_cell_25 */

#ifndef struct_c1_tag_sQqzhT6lgzOQlKB8EVZ4HF
#define struct_c1_tag_sQqzhT6lgzOQlKB8EVZ4HF

struct c1_tag_sQqzhT6lgzOQlKB8EVZ4HF
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[6];
  char_T f4[7];
  char_T f5[8];
  char_T f6[3];
};

#endif                                 /* struct_c1_tag_sQqzhT6lgzOQlKB8EVZ4HF */

#ifndef typedef_c1_cell_26
#define typedef_c1_cell_26

typedef struct c1_tag_sQqzhT6lgzOQlKB8EVZ4HF c1_cell_26;

#endif                                 /* typedef_c1_cell_26 */

#ifndef struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD
#define struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD

struct c1_tag_tP4ysjhyvuYk36JuHDg8bD
{
  c1_s_a7TcNrdk5JZcy5uxGijaRG _data;
};

#endif                                 /* struct_c1_tag_tP4ysjhyvuYk36JuHDg8bD */

#ifndef typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD
#define typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD

typedef struct c1_tag_tP4ysjhyvuYk36JuHDg8bD c1_s_tP4ysjhyvuYk36JuHDg8bD;

#endif                                 /* typedef_c1_s_tP4ysjhyvuYk36JuHDg8bD */

#ifndef struct_c1_tag_ynaaIE6q9xznGBkza31TCF
#define struct_c1_tag_ynaaIE6q9xznGBkza31TCF

struct c1_tag_ynaaIE6q9xznGBkza31TCF
{
  c1_cell_1 _data;
};

#endif                                 /* struct_c1_tag_ynaaIE6q9xznGBkza31TCF */

#ifndef typedef_c1_s_ynaaIE6q9xznGBkza31TCF
#define typedef_c1_s_ynaaIE6q9xznGBkza31TCF

typedef struct c1_tag_ynaaIE6q9xznGBkza31TCF c1_s_ynaaIE6q9xznGBkza31TCF;

#endif                                 /* typedef_c1_s_ynaaIE6q9xznGBkza31TCF */

#ifndef struct_c1_tag_y30bjXPnZrp2waraWnJSvH
#define struct_c1_tag_y30bjXPnZrp2waraWnJSvH

struct c1_tag_y30bjXPnZrp2waraWnJSvH
{
  c1_cell_2 _data;
};

#endif                                 /* struct_c1_tag_y30bjXPnZrp2waraWnJSvH */

#ifndef typedef_c1_s_y30bjXPnZrp2waraWnJSvH
#define typedef_c1_s_y30bjXPnZrp2waraWnJSvH

typedef struct c1_tag_y30bjXPnZrp2waraWnJSvH c1_s_y30bjXPnZrp2waraWnJSvH;

#endif                                 /* typedef_c1_s_y30bjXPnZrp2waraWnJSvH */

#ifndef struct_c1_tag_hq4Z13O5hXdQ9UsncvBGlF
#define struct_c1_tag_hq4Z13O5hXdQ9UsncvBGlF

struct c1_tag_hq4Z13O5hXdQ9UsncvBGlF
{
  c1_cell_3 _data;
};

#endif                                 /* struct_c1_tag_hq4Z13O5hXdQ9UsncvBGlF */

#ifndef typedef_c1_s_hq4Z13O5hXdQ9UsncvBGlF
#define typedef_c1_s_hq4Z13O5hXdQ9UsncvBGlF

typedef struct c1_tag_hq4Z13O5hXdQ9UsncvBGlF c1_s_hq4Z13O5hXdQ9UsncvBGlF;

#endif                                 /* typedef_c1_s_hq4Z13O5hXdQ9UsncvBGlF */

#ifndef struct_c1_tag_GZjSpaey3IDRqvh7nZoQMD
#define struct_c1_tag_GZjSpaey3IDRqvh7nZoQMD

struct c1_tag_GZjSpaey3IDRqvh7nZoQMD
{
  c1_cell_wrap_4 _data;
};

#endif                                 /* struct_c1_tag_GZjSpaey3IDRqvh7nZoQMD */

#ifndef typedef_c1_s_GZjSpaey3IDRqvh7nZoQMD
#define typedef_c1_s_GZjSpaey3IDRqvh7nZoQMD

typedef struct c1_tag_GZjSpaey3IDRqvh7nZoQMD c1_s_GZjSpaey3IDRqvh7nZoQMD;

#endif                                 /* typedef_c1_s_GZjSpaey3IDRqvh7nZoQMD */

#ifndef struct_c1_tag_zhWislg2JXfOJCG0FlayVG
#define struct_c1_tag_zhWislg2JXfOJCG0FlayVG

struct c1_tag_zhWislg2JXfOJCG0FlayVG
{
  c1_cell_5 _data;
};

#endif                                 /* struct_c1_tag_zhWislg2JXfOJCG0FlayVG */

#ifndef typedef_c1_s_zhWislg2JXfOJCG0FlayVG
#define typedef_c1_s_zhWislg2JXfOJCG0FlayVG

typedef struct c1_tag_zhWislg2JXfOJCG0FlayVG c1_s_zhWislg2JXfOJCG0FlayVG;

#endif                                 /* typedef_c1_s_zhWislg2JXfOJCG0FlayVG */

#ifndef struct_c1_tag_BrRdqYMft44ulwR1A7rKqF
#define struct_c1_tag_BrRdqYMft44ulwR1A7rKqF

struct c1_tag_BrRdqYMft44ulwR1A7rKqF
{
  c1_cell_wrap_6 _data;
};

#endif                                 /* struct_c1_tag_BrRdqYMft44ulwR1A7rKqF */

#ifndef typedef_c1_s_BrRdqYMft44ulwR1A7rKqF
#define typedef_c1_s_BrRdqYMft44ulwR1A7rKqF

typedef struct c1_tag_BrRdqYMft44ulwR1A7rKqF c1_s_BrRdqYMft44ulwR1A7rKqF;

#endif                                 /* typedef_c1_s_BrRdqYMft44ulwR1A7rKqF */

#ifndef struct_c1_tag_lnEOVMt12CNg5nSw1iwvNF
#define struct_c1_tag_lnEOVMt12CNg5nSw1iwvNF

struct c1_tag_lnEOVMt12CNg5nSw1iwvNF
{
  c1_cell_wrap_7 _data;
};

#endif                                 /* struct_c1_tag_lnEOVMt12CNg5nSw1iwvNF */

#ifndef typedef_c1_s_lnEOVMt12CNg5nSw1iwvNF
#define typedef_c1_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct c1_tag_lnEOVMt12CNg5nSw1iwvNF c1_s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* typedef_c1_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef struct_c1_tag_Uq8YUzQmSy3K1TONPeIAhC
#define struct_c1_tag_Uq8YUzQmSy3K1TONPeIAhC

struct c1_tag_Uq8YUzQmSy3K1TONPeIAhC
{
  c1_cell_8 _data;
};

#endif                                 /* struct_c1_tag_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef typedef_c1_s_Uq8YUzQmSy3K1TONPeIAhC
#define typedef_c1_s_Uq8YUzQmSy3K1TONPeIAhC

typedef struct c1_tag_Uq8YUzQmSy3K1TONPeIAhC c1_s_Uq8YUzQmSy3K1TONPeIAhC;

#endif                                 /* typedef_c1_s_Uq8YUzQmSy3K1TONPeIAhC */

#ifndef struct_c1_tag_i8jNnI3x8wo4JAox5HV9WF
#define struct_c1_tag_i8jNnI3x8wo4JAox5HV9WF

struct c1_tag_i8jNnI3x8wo4JAox5HV9WF
{
  c1_cell_9 _data;
};

#endif                                 /* struct_c1_tag_i8jNnI3x8wo4JAox5HV9WF */

#ifndef typedef_c1_s_i8jNnI3x8wo4JAox5HV9WF
#define typedef_c1_s_i8jNnI3x8wo4JAox5HV9WF

typedef struct c1_tag_i8jNnI3x8wo4JAox5HV9WF c1_s_i8jNnI3x8wo4JAox5HV9WF;

#endif                                 /* typedef_c1_s_i8jNnI3x8wo4JAox5HV9WF */

#ifndef struct_c1_tag_dV11HShs2d9BqwRJb6HgvD
#define struct_c1_tag_dV11HShs2d9BqwRJb6HgvD

struct c1_tag_dV11HShs2d9BqwRJb6HgvD
{
  c1_cell_10 _data;
};

#endif                                 /* struct_c1_tag_dV11HShs2d9BqwRJb6HgvD */

#ifndef typedef_c1_s_dV11HShs2d9BqwRJb6HgvD
#define typedef_c1_s_dV11HShs2d9BqwRJb6HgvD

typedef struct c1_tag_dV11HShs2d9BqwRJb6HgvD c1_s_dV11HShs2d9BqwRJb6HgvD;

#endif                                 /* typedef_c1_s_dV11HShs2d9BqwRJb6HgvD */

#ifndef struct_c1_tag_HSHOljOSgF7qDZeWd2IfH
#define struct_c1_tag_HSHOljOSgF7qDZeWd2IfH

struct c1_tag_HSHOljOSgF7qDZeWd2IfH
{
  c1_cell_11 _data;
};

#endif                                 /* struct_c1_tag_HSHOljOSgF7qDZeWd2IfH */

#ifndef typedef_c1_s_HSHOljOSgF7qDZeWd2IfH
#define typedef_c1_s_HSHOljOSgF7qDZeWd2IfH

typedef struct c1_tag_HSHOljOSgF7qDZeWd2IfH c1_s_HSHOljOSgF7qDZeWd2IfH;

#endif                                 /* typedef_c1_s_HSHOljOSgF7qDZeWd2IfH */

#ifndef struct_c1_tag_HOps0FrfA6RiWumqewPwZD
#define struct_c1_tag_HOps0FrfA6RiWumqewPwZD

struct c1_tag_HOps0FrfA6RiWumqewPwZD
{
  c1_cell_wrap_0 _data;
};

#endif                                 /* struct_c1_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_c1_s_HOps0FrfA6RiWumqewPwZD
#define typedef_c1_s_HOps0FrfA6RiWumqewPwZD

typedef struct c1_tag_HOps0FrfA6RiWumqewPwZD c1_s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_c1_s_HOps0FrfA6RiWumqewPwZD */

#ifndef struct_c1_tag_23YJI910RYCWhAsXw5RjrG
#define struct_c1_tag_23YJI910RYCWhAsXw5RjrG

struct c1_tag_23YJI910RYCWhAsXw5RjrG
{
  c1_cell_12 _data;
};

#endif                                 /* struct_c1_tag_23YJI910RYCWhAsXw5RjrG */

#ifndef typedef_c1_s_23YJI910RYCWhAsXw5RjrG
#define typedef_c1_s_23YJI910RYCWhAsXw5RjrG

typedef struct c1_tag_23YJI910RYCWhAsXw5RjrG c1_s_23YJI910RYCWhAsXw5RjrG;

#endif                                 /* typedef_c1_s_23YJI910RYCWhAsXw5RjrG */

#ifndef struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH
#define struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH

struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH
{
  c1_cell_13 _data;
};

#endif                                 /* struct_c1_tag_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH
#define typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH

typedef struct c1_tag_i3ZGqykvgqQLsMCH6x4OBH c1_s_i3ZGqykvgqQLsMCH6x4OBH;

#endif                                 /* typedef_c1_s_i3ZGqykvgqQLsMCH6x4OBH */

#ifndef struct_c1_tag_u4ui3JwwaZ1jYzDQeNl7gB
#define struct_c1_tag_u4ui3JwwaZ1jYzDQeNl7gB

struct c1_tag_u4ui3JwwaZ1jYzDQeNl7gB
{
  c1_cell_15 _data;
};

#endif                                 /* struct_c1_tag_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef typedef_c1_s_u4ui3JwwaZ1jYzDQeNl7gB
#define typedef_c1_s_u4ui3JwwaZ1jYzDQeNl7gB

typedef struct c1_tag_u4ui3JwwaZ1jYzDQeNl7gB c1_s_u4ui3JwwaZ1jYzDQeNl7gB;

#endif                                 /* typedef_c1_s_u4ui3JwwaZ1jYzDQeNl7gB */

#ifndef struct_c1_tag_lv60kHidgCVN68cHDjBCkF
#define struct_c1_tag_lv60kHidgCVN68cHDjBCkF

struct c1_tag_lv60kHidgCVN68cHDjBCkF
{
  c1_cell_16 _data;
};

#endif                                 /* struct_c1_tag_lv60kHidgCVN68cHDjBCkF */

#ifndef typedef_c1_s_lv60kHidgCVN68cHDjBCkF
#define typedef_c1_s_lv60kHidgCVN68cHDjBCkF

typedef struct c1_tag_lv60kHidgCVN68cHDjBCkF c1_s_lv60kHidgCVN68cHDjBCkF;

#endif                                 /* typedef_c1_s_lv60kHidgCVN68cHDjBCkF */

#ifndef struct_c1_tag_MQfHiYk2RSY7P6gdFv6fDB
#define struct_c1_tag_MQfHiYk2RSY7P6gdFv6fDB

struct c1_tag_MQfHiYk2RSY7P6gdFv6fDB
{
  c1_cell_17 _data;
};

#endif                                 /* struct_c1_tag_MQfHiYk2RSY7P6gdFv6fDB */

#ifndef typedef_c1_s_MQfHiYk2RSY7P6gdFv6fDB
#define typedef_c1_s_MQfHiYk2RSY7P6gdFv6fDB

typedef struct c1_tag_MQfHiYk2RSY7P6gdFv6fDB c1_s_MQfHiYk2RSY7P6gdFv6fDB;

#endif                                 /* typedef_c1_s_MQfHiYk2RSY7P6gdFv6fDB */

#ifndef struct_c1_tag_zyomqXisN60TlgNyBJHFGG
#define struct_c1_tag_zyomqXisN60TlgNyBJHFGG

struct c1_tag_zyomqXisN60TlgNyBJHFGG
{
  c1_cell_18 _data;
};

#endif                                 /* struct_c1_tag_zyomqXisN60TlgNyBJHFGG */

#ifndef typedef_c1_s_zyomqXisN60TlgNyBJHFGG
#define typedef_c1_s_zyomqXisN60TlgNyBJHFGG

typedef struct c1_tag_zyomqXisN60TlgNyBJHFGG c1_s_zyomqXisN60TlgNyBJHFGG;

#endif                                 /* typedef_c1_s_zyomqXisN60TlgNyBJHFGG */

#ifndef struct_c1_tag_7xbvANdg7KAufDVBBSkgZE
#define struct_c1_tag_7xbvANdg7KAufDVBBSkgZE

struct c1_tag_7xbvANdg7KAufDVBBSkgZE
{
  c1_cell_19 _data;
};

#endif                                 /* struct_c1_tag_7xbvANdg7KAufDVBBSkgZE */

#ifndef typedef_c1_s_7xbvANdg7KAufDVBBSkgZE
#define typedef_c1_s_7xbvANdg7KAufDVBBSkgZE

typedef struct c1_tag_7xbvANdg7KAufDVBBSkgZE c1_s_7xbvANdg7KAufDVBBSkgZE;

#endif                                 /* typedef_c1_s_7xbvANdg7KAufDVBBSkgZE */

#ifndef struct_c1_tag_FT1dThmKyyOBY5mTNhhCiC
#define struct_c1_tag_FT1dThmKyyOBY5mTNhhCiC

struct c1_tag_FT1dThmKyyOBY5mTNhhCiC
{
  c1_cell_20 _data;
};

#endif                                 /* struct_c1_tag_FT1dThmKyyOBY5mTNhhCiC */

#ifndef typedef_c1_s_FT1dThmKyyOBY5mTNhhCiC
#define typedef_c1_s_FT1dThmKyyOBY5mTNhhCiC

typedef struct c1_tag_FT1dThmKyyOBY5mTNhhCiC c1_s_FT1dThmKyyOBY5mTNhhCiC;

#endif                                 /* typedef_c1_s_FT1dThmKyyOBY5mTNhhCiC */

#ifndef struct_c1_tag_LiC67LW1mMO192u9sMnmMG
#define struct_c1_tag_LiC67LW1mMO192u9sMnmMG

struct c1_tag_LiC67LW1mMO192u9sMnmMG
{
  c1_cell_21 _data;
};

#endif                                 /* struct_c1_tag_LiC67LW1mMO192u9sMnmMG */

#ifndef typedef_c1_s_LiC67LW1mMO192u9sMnmMG
#define typedef_c1_s_LiC67LW1mMO192u9sMnmMG

typedef struct c1_tag_LiC67LW1mMO192u9sMnmMG c1_s_LiC67LW1mMO192u9sMnmMG;

#endif                                 /* typedef_c1_s_LiC67LW1mMO192u9sMnmMG */

#ifndef struct_c1_tag_MNdGPE827fhwyzcwIbJ2SF
#define struct_c1_tag_MNdGPE827fhwyzcwIbJ2SF

struct c1_tag_MNdGPE827fhwyzcwIbJ2SF
{
  c1_cell_22 _data;
};

#endif                                 /* struct_c1_tag_MNdGPE827fhwyzcwIbJ2SF */

#ifndef typedef_c1_s_MNdGPE827fhwyzcwIbJ2SF
#define typedef_c1_s_MNdGPE827fhwyzcwIbJ2SF

typedef struct c1_tag_MNdGPE827fhwyzcwIbJ2SF c1_s_MNdGPE827fhwyzcwIbJ2SF;

#endif                                 /* typedef_c1_s_MNdGPE827fhwyzcwIbJ2SF */

#ifndef struct_c1_tag_GvWTNEJOSSRh883m2SnETB
#define struct_c1_tag_GvWTNEJOSSRh883m2SnETB

struct c1_tag_GvWTNEJOSSRh883m2SnETB
{
  c1_cell_23 _data;
};

#endif                                 /* struct_c1_tag_GvWTNEJOSSRh883m2SnETB */

#ifndef typedef_c1_s_GvWTNEJOSSRh883m2SnETB
#define typedef_c1_s_GvWTNEJOSSRh883m2SnETB

typedef struct c1_tag_GvWTNEJOSSRh883m2SnETB c1_s_GvWTNEJOSSRh883m2SnETB;

#endif                                 /* typedef_c1_s_GvWTNEJOSSRh883m2SnETB */

#ifndef struct_c1_tag_Z2qSppxNoXb8Jppd82oq6F
#define struct_c1_tag_Z2qSppxNoXb8Jppd82oq6F

struct c1_tag_Z2qSppxNoXb8Jppd82oq6F
{
  c1_cell_24 _data;
};

#endif                                 /* struct_c1_tag_Z2qSppxNoXb8Jppd82oq6F */

#ifndef typedef_c1_s_Z2qSppxNoXb8Jppd82oq6F
#define typedef_c1_s_Z2qSppxNoXb8Jppd82oq6F

typedef struct c1_tag_Z2qSppxNoXb8Jppd82oq6F c1_s_Z2qSppxNoXb8Jppd82oq6F;

#endif                                 /* typedef_c1_s_Z2qSppxNoXb8Jppd82oq6F */

#ifndef struct_c1_tag_bfdw51ZQJqFWZgII8x0zkH
#define struct_c1_tag_bfdw51ZQJqFWZgII8x0zkH

struct c1_tag_bfdw51ZQJqFWZgII8x0zkH
{
  c1_cell_25 _data;
};

#endif                                 /* struct_c1_tag_bfdw51ZQJqFWZgII8x0zkH */

#ifndef typedef_c1_s_bfdw51ZQJqFWZgII8x0zkH
#define typedef_c1_s_bfdw51ZQJqFWZgII8x0zkH

typedef struct c1_tag_bfdw51ZQJqFWZgII8x0zkH c1_s_bfdw51ZQJqFWZgII8x0zkH;

#endif                                 /* typedef_c1_s_bfdw51ZQJqFWZgII8x0zkH */

#ifndef struct_c1_tag_Zk8dErMjLMrsJtNaWjimqH
#define struct_c1_tag_Zk8dErMjLMrsJtNaWjimqH

struct c1_tag_Zk8dErMjLMrsJtNaWjimqH
{
  c1_cell_26 _data;
};

#endif                                 /* struct_c1_tag_Zk8dErMjLMrsJtNaWjimqH */

#ifndef typedef_c1_s_Zk8dErMjLMrsJtNaWjimqH
#define typedef_c1_s_Zk8dErMjLMrsJtNaWjimqH

typedef struct c1_tag_Zk8dErMjLMrsJtNaWjimqH c1_s_Zk8dErMjLMrsJtNaWjimqH;

#endif                                 /* typedef_c1_s_Zk8dErMjLMrsJtNaWjimqH */

#ifndef typedef_SFc1_flightControlSystemInstanceStruct
#define typedef_SFc1_flightControlSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c1_sfEvent;
  boolean_T c1_doneDoubleBufferReInit;
  uint8_T c1_is_active_c1_flightControlSystem;
  uint8_T c1_JITStateAnimation[1];
  uint8_T c1_JITTransitionAnimation[1];
  int32_T c1_IsDebuggerActive;
  int32_T c1_IsSequenceViewerPresent;
  int32_T c1_SequenceViewerOptimization;
  int32_T c1_IsHeatMapPresent;
  void *c1_RuntimeVar;
  uint32_T c1_mlFcnLineNumber;
  void *c1_fcnDataPtrs[6];
  char_T *c1_dataNames[6];
  uint32_T c1_numFcnVars;
  uint32_T c1_ssIds[6];
  uint32_T c1_statuses[6];
  void *c1_outMexFcns[6];
  void *c1_inMexFcns[6];
  real_T c1_H[70740];
  real_T c1_hnew[70740];
  real_T c1_varargin_1[70740];
  real_T c1_a[20540];
  real_T c1_b_a[20540];
  real_T c1_b_dv[18644];
  real_T c1_i1[18644];
  real_T c1_b_i1[18644];
  real_T c1_i2[18644];
  real_T c1_b_i2[18644];
  real_T c1_magGrad[18644];
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  real_T (*c1_BWimage)[18644];
  real_T *c1_DegAngle;
} SFc1_flightControlSystemInstanceStruct;

#endif                                 /* typedef_SFc1_flightControlSystemInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_flightControlSystem_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c1_flightControlSystem_get_check_sum(mxArray *plhs[]);
extern void c1_flightControlSystem_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
